const demoMode = typeof location !== 'undefined' && new URLSearchParams(location.search).get('demo') === '1';
const DB_NAME = demoMode ? 'DividendOSDB_QA' : 'DividendOSDB_V4';
const DB_VERSION = 1;
const STORE_NAME = 'kv';
let database;
let storageMode = 'indexeddb';
const memoryStore = new Map();
const FALLBACK_PREFIX = demoMode ? 'dividend-os-qa:' : 'dividend-os-v4:';
const FALLBACK_MODE_KEY = `${FALLBACK_PREFIX}storage-backend`;
const LEGACY_DB_NAME = 'MSTYProject1000DB_V3';
const FUNDING_STATE_KEY = 'stateFundingV1';
let expectedFundingJSON;
const snapshotJSON = (value) => value === undefined ? undefined : JSON.stringify(value);
const rememberRead = (key, value) => { if (key === FUNDING_STATE_KEY)
    expectedFundingJSON = snapshotJSON(value); return value; };
const assertUnchanged = (key, current) => { if (key === FUNDING_STATE_KEY && snapshotJSON(current) !== expectedFundingJSON)
    throw new Error('다른 화면에서 기록이 바뀌었습니다. 현재 입력을 보관하고 앱을 다시 열어 최신 기록을 확인해 주세요.'); };
export const storageStatus = () => ({ mode: storageMode, durable: storageMode !== 'memory' });
function enableFallback() {
    try {
        const probe = `${FALLBACK_PREFIX}probe`;
        localStorage.setItem(probe, '1');
        localStorage.removeItem(probe);
        localStorage.setItem(FALLBACK_MODE_KEY, 'localstorage');
        storageMode = 'localstorage';
    }
    catch (_) {
        storageMode = 'memory';
    }
}
export function openStorage() {
    return new Promise((resolve, reject) => {
        // Keep using the durable backend holding the last saved ledger.
        // Preserve the marker after deletion so an old IndexedDB ledger cannot reappear.
        try {
            if (localStorage.getItem(FALLBACK_MODE_KEY) === 'localstorage' || localStorage.getItem(`${FALLBACK_PREFIX}state`) !== null) {
                storageMode = 'localstorage';
                try {
                    localStorage.setItem(FALLBACK_MODE_KEY, 'localstorage');
                }
                catch (_) { }
                resolve(null);
                return;
            }
        }
        catch (_) { }
        if (typeof indexedDB === 'undefined') {
            enableFallback();
            resolve(null);
            return;
        }
        let request;
        try {
            request = indexedDB.open(DB_NAME, DB_VERSION);
        }
        catch (_) {
            enableFallback();
            resolve(null);
            return;
        }
        request.onupgradeneeded = () => {
            const db = request.result;
            if (!db.objectStoreNames.contains(STORE_NAME))
                db.createObjectStore(STORE_NAME);
        };
        request.onsuccess = () => {
            database = request.result;
            resolve(database);
        };
        request.onerror = () => { console.warn('IndexedDB unavailable; using fallback storage.', request.error); enableFallback(); resolve(null); };
        request.onblocked = () => { console.warn('IndexedDB blocked; using fallback storage.'); enableFallback(); resolve(null); };
    });
}
export function storageGet(key) {
    if (storageMode === 'memory')
        return Promise.resolve(rememberRead(key, memoryStore.get(key)));
    if (storageMode === 'localstorage') {
        try {
            const value = localStorage.getItem(`${FALLBACK_PREFIX}${key}`);
            return Promise.resolve(rememberRead(key, value ? JSON.parse(value) : undefined));
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    return new Promise((resolve, reject) => {
        const tx = database.transaction(STORE_NAME, 'readonly');
        const request = tx.objectStore(STORE_NAME).get(key);
        request.onsuccess = () => resolve(rememberRead(key, request.result));
        request.onerror = () => reject(request.error);
    });
}
export function storageSet(key, value) {
    // Capture bytes before awaiting a lock/transaction so later UI edits cannot
    // change the snapshot being committed.
    const frozen = key === FUNDING_STATE_KEY ? JSON.parse(JSON.stringify(value)) : value;
    if (storageMode === 'memory') {
        try {
            assertUnchanged(key, memoryStore.get(key));
            memoryStore.set(key, frozen);
            rememberRead(key, frozen);
            return Promise.resolve();
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    if (storageMode === 'localstorage') {
        const write = () => { const current = localStorage.getItem(`${FALLBACK_PREFIX}${key}`); assertUnchanged(key, current ? JSON.parse(current) : undefined); localStorage.setItem(`${FALLBACK_PREFIX}${key}`, JSON.stringify(frozen)); rememberRead(key, frozen); };
        if (key === FUNDING_STATE_KEY && typeof navigator !== 'undefined' && navigator.locks)
            return navigator.locks.request(`${DB_NAME}:${key}`, write);
        try {
            write();
            return Promise.resolve();
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    return new Promise((resolve, reject) => {
        const tx = database.transaction(STORE_NAME, 'readwrite');
        const store = tx.objectStore(STORE_NAME);
        let conflict;
        if (key === FUNDING_STATE_KEY) {
            const current = store.get(key);
            current.onsuccess = () => { try {
                assertUnchanged(key, current.result);
                store.put(frozen, key);
            }
            catch (error) {
                conflict = error;
                tx.abort();
            } };
        }
        else
            store.put(frozen, key);
        tx.oncomplete = () => { rememberRead(key, frozen); resolve(); };
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(conflict || tx.error || new Error('저장 작업이 중단되었습니다.'));
    });
}
export function storageDelete(key) {
    if (storageMode === 'memory') {
        memoryStore.delete(key);
        return Promise.resolve();
    }
    if (storageMode === 'localstorage') {
        try {
            localStorage.removeItem(`${FALLBACK_PREFIX}${key}`);
            return Promise.resolve();
        }
        catch (error) {
            return Promise.reject(error);
        }
    }
    return new Promise((resolve, reject) => {
        const tx = database.transaction(STORE_NAME, 'readwrite');
        tx.objectStore(STORE_NAME).delete(key);
        tx.oncomplete = () => resolve();
        tx.onerror = () => reject(tx.error);
        tx.onabort = () => reject(tx.error || new Error('삭제 작업이 중단되었습니다.'));
    });
}
export async function readLegacyState(key = 'state') {
    if (typeof indexedDB === 'undefined')
        return null;
    try {
        if (typeof indexedDB.databases === 'function') {
            const databases = await indexedDB.databases();
            if (!databases.some((item) => item.name === LEGACY_DB_NAME))
                return null;
        }
    }
    catch (_) { }
    return new Promise(resolve => {
        // Omit the version so a harmless V3 schema upgrade remains readable.
        let request;
        try {
            request = indexedDB.open(LEGACY_DB_NAME);
        }
        catch (_) {
            resolve(null);
            return;
        }
        request.onupgradeneeded = () => { request.transaction?.abort(); resolve(null); };
        request.onerror = () => resolve(null);
        request.onsuccess = () => {
            const legacy = request.result;
            if (!legacy.objectStoreNames.contains(STORE_NAME)) {
                legacy.close();
                resolve(null);
                return;
            }
            const tx = legacy.transaction(STORE_NAME, 'readonly');
            const get = tx.objectStore(STORE_NAME).get(key);
            get.onsuccess = () => { legacy.close(); resolve(get.result || null); };
            get.onerror = () => { legacy.close(); resolve(null); };
        };
    });
}
