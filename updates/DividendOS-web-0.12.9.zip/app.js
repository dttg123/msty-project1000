import { monthActivity } from './modules/activity.js';
import { initGoogleAuth, logoutGoogle } from './modules/cloud-api.js';
import { openStorage, storageGet, storageSet, storageDelete, readLegacyState, storageStatus } from './storage.js';
import { getCloudDocument, getLegacyCloudDocument, saveCloudDocument, subscribeCloudDocument } from './modules/cloud-api.js';
import { APP_VERSION, DATA_SCHEMA_VERSION, buildCsvExportZip, buildPortableBackup, readStateFromBackupFile } from './backup.js';
import { PAGES, PROJECT_CATEGORIES, PROJECT_COLORS, PROJECT_COLOR_NAMES, SAFETY_KEY, STATE_KEY } from './modules/constants.js';
import { blankProject, blankState, migrate, migrateLegacy } from './modules/state.js';
import { createPortfolioEngine } from './modules/portfolio.js';
import { createFormatters } from './modules/format.js';
import { createViews } from './modules/views.js';
import { buildMigrationAudit } from './modules/migration.js';
import { accountScopeChanged, automaticTossDividendAdoptions, automaticTossImportPlan, buildTossSync, disconnectedTossState, mergeTossCandidates, mergeTossCorrectionCandidates, mergeTossDividendCandidates, mergeTossSourceLedger, nextTossSyncFrom, normalizeTossOrder, tossCandidateToTrade, tossCandidateToDividend, tossSyncProgress } from './modules/toss.js';
import { fetchTossSnapshot, isTossBridgeConfigured, readTossSnapshotFile, removeLegacyTossBrowserCredentials } from './toss-client.js';
import { clearNativeTossCredentials, fetchNativeTossSnapshot, isNativeTossAvailable, markNativeTossPublicIp, nativePublicIp, nativeTossCredentialStatus, openTossIpManagement, saveNativeTossCredentials } from './toss-native.js';
import { validateLedger } from './modules/validation.js';
import { demoState } from './modules/demo.js';
import { FREQUENCIES } from './modules/income.js';
import { clone, esc, isDate, n, round, todayISO, uid } from './modules/utils.js';
import { listAutoBackups, readAutoBackup, rotateAutoBackups } from './modules/backup-history.js';
import { tickerChange } from './modules/corporate-actions.js';
import { confirmHotUpdateReady, hotUpdateStatus as fetchHotUpdateStatus, installHotUpdate, isHotUpdateAvailable } from './hot-update.js';
(() => {
    'use strict';
    const bootAt = performance.now();
    const demoMode = new URLSearchParams(location.search).get('demo') === '1';
    let state;
    let currentPage = 'home';
    let selectedProjectId = '';
    let chartMode = 'month';
    let chartSelection = '';
    let homeCashflowMode = 'month';
    let homeYearRange = '6';
    let historyFilter = {}, chartMonth = '', chartYear = '';
    let historyLimit = 10, modalDirty = false, modalSaving = false, modalFocus = null, modalScroll = 0;
    let cashflowMonthKey = '';
    let portfolioGroup = 'highYield';
    const viewKey = `dividend-os-view-v2:${demoMode ? 'demo' : 'local'}`;
    function rememberView() { try {
        localStorage.setItem(viewKey, JSON.stringify({ page: currentPage === 'settings' ? 'home' : currentPage, selectedProjectId, portfolioGroup, chartMode, chartMonth, chartYear, homeCashflowMode, homeYearRange }));
    }
    catch (_) { } }
    function restoreView() { try {
        const saved = JSON.parse(localStorage.getItem(viewKey) || 'null');
        if (!saved)
            return;
        const project = activeProjects().find((p) => p.id === saved.selectedProjectId);
        if (project)
            selectedProjectId = project.id;
        const savedGroup = saved.portfolioGroup || (saved.portfolioCategory === 'highYield' ? 'highYield' : saved.portfolioCategory ? 'dividend' : '');
        if (['highYield', 'dividend'].includes(savedGroup))
            portfolioGroup = savedGroup;
        if (['home', 'projects', 'goal'].includes(saved.page))
            currentPage = saved.page;
        if (['week', 'month', 'year', 'monthWeeks'].includes(saved.chartMode))
            chartMode = saved.chartMode;
        if (['month', 'year'].includes(saved.homeCashflowMode))
            homeCashflowMode = saved.homeCashflowMode;
        if (['6', '10', 'all'].includes(saved.homeYearRange))
            homeYearRange = saved.homeYearRange;
        if (/^\d{4}-\d{2}$/.test(saved.chartMonth || ''))
            chartMonth = saved.chartMonth;
        if (/^\d{4}$/.test(saved.chartYear || ''))
            chartYear = saved.chartYear;
    }
    catch (_) { } }
    let currentUser = null;
    let cloudReady = false, pendingCloudState = null, cloudChoiceResolve = null;
    let cloudUnsubscribe = null;
    let applyingCloudState = false;
    let saveTimer = null;
    let cloudTimer = null;
    let cloudRevision = 0;
    let cloudWritePending = false;
    let toastTimer = null;
    let legacyMigrationSource = null;
    let tossSyncRunning = false;
    let nativeTossStatus = { available: isNativeTossAvailable(), configured: false, publicIp: '', lastPublicIp: '', checking: false };
    let appUpdateStatus = { available: isHotUpdateAvailable(), checking: false, currentVersion: APP_VERSION, latestVersion: APP_VERSION, updateAvailable: false, nativeUpdateRequired: false, error: '' };
    let pendingTossIp = '';
    let localOnlySession = sessionStorage.getItem('dividend-os-local-mode') === '1';
    let autoBackupStatus = { count: 0, lastAt: '', error: '' }, autoBackupPromise = null;
    const portfolio = createPortfolioEngine(() => state, () => selectedProjectId);
    const { activeProjects, projectById, projectRows, sharesAtDate, computeProject, recoveryStats, totals } = portfolio;
    const formatters = createFormatters(() => state);
    const { displayCurrency, fmtMoney, fmtSignedMoney, fmtShares, fmtPct, fmtDate, signClass, projectColors } = formatters;
    function applyTheme(pref = state?.settings?.appearance || 'system') {
        const dark = pref === 'dark' || (pref === 'system' && matchMedia('(prefers-color-scheme:dark)').matches);
        document.documentElement.dataset.theme = dark ? 'dark' : 'light';
        localStorage.setItem('dividend-os-theme', pref);
        document.querySelector('meta[name="theme-color"]')?.setAttribute('content', dark ? '#0f1117' : '#f4f5f9');
    }
    function hideSplash() {
        const splash = document.getElementById('splashScreen');
        if (!splash)
            return;
        setTimeout(() => { splash.classList.add('hide'); setTimeout(() => splash.remove(), 240); }, Math.max(0, 330 - (performance.now() - bootAt)));
    }
    function toast(message, { haptic = false } = {}) {
        const el = document.getElementById('toast');
        clearTimeout(toastTimer);
        el.textContent = message;
        el.classList.add('show');
        if (haptic)
            try {
                navigator.vibrate?.(18);
            }
            catch (_) { }
        toastTimer = setTimeout(() => el.classList.remove('show'), 2300);
    }
    function setSaveStatus(text, kind = '') { const el = document.getElementById('saveStatus'); if (el) {
        el.textContent = text;
        el.className = `save-pill ${kind}`;
    } }
    function hasMeaningfulData(value = state) { return !!(value && (value.trades?.length || value.dividends?.length || value.splits?.length || value.cashAdjustments?.length || value.projects?.some((p) => n(p.currentPrice) || n(p.monthlyPlanShares) || n(p.initialDividendBalance)))); }
    const backupStorage = { get: storageGet, set: storageSet, remove: storageDelete };
    async function refreshAutoBackupStatus() { const entries = await listAutoBackups(backupStorage); autoBackupStatus = { count: entries.length, lastAt: entries[0]?.createdAt || '', error: '' }; return entries; }
    async function autoBackup(reason = 'automatic') {
        if (demoMode || !hasMeaningfulData())
            return;
        if (autoBackupPromise)
            return autoBackupPromise;
        autoBackupPromise = rotateAutoBackups(backupStorage, clone(state), { reason }).then(result => { autoBackupStatus = { count: result.entries.length, lastAt: result.entries[0]?.createdAt || '', error: '' }; return result; }).catch(error => { console.error(error); autoBackupStatus = { ...autoBackupStatus, error: '자동 백업 실패' }; return null; }).finally(() => { autoBackupPromise = null; });
        return autoBackupPromise;
    }
    async function pushCloudState() {
        if (demoMode || !currentUser || !cloudReady || applyingCloudState)
            return;
        if (!navigator.onLine) {
            setSaveStatus('오프라인', 'cloud-error');
            return;
        }
        try {
            setSaveStatus('동기화 중', 'cloud-busy');
            const now = new Date().toISOString();
            state.meta.lastCloudSaveAt = now;
            cloudWritePending = true;
            const saved = await saveCloudDocument(currentUser.uid, clone(state), { expectedRevision: cloudRevision, appVersion: APP_VERSION });
            cloudRevision = saved.revision;
            cloudWritePending = false;
            await storageSet(STATE_KEY, state);
            setSaveStatus('', 'cloud-ok');
        }
        catch (error) {
            cloudWritePending = false;
            console.error(error);
            if (error?.code === 'cloud-conflict') {
                const latest = await getCloudDocument(currentUser.uid).catch(() => null);
                pendingCloudState = latest?.state ? migrate(latest.state) : null;
                cloudRevision = Math.max(cloudRevision, n(latest?.revision));
                cloudReady = false;
                await autoBackup('cloud-conflict');
                setSaveStatus('다른 기기 변경 · 확인 필요', 'cloud-error');
                toast('다른 기기 변경을 발견해 덮어쓰지 않았습니다.', { haptic: true });
                renderAll();
                return;
            }
            setSaveStatus('클라우드 오류', 'cloud-error');
            toast('기기에는 저장됐지만 클라우드 저장에 실패했습니다.', { haptic: true });
        }
    }
    async function saveState(immediate = false) {
        state.meta.updatedAt = new Date().toISOString();
        clearTimeout(saveTimer);
        clearTimeout(cloudTimer);
        const run = async () => { state.meta.lastLocalSaveAt = new Date().toISOString(); try {
            await storageSet(STATE_KEY, state);
            await autoBackup('ledger-change');
        }
        catch (error) {
            setSaveStatus('저장 실패 · 백업 필요', 'cloud-error');
            toast('기기 저장에 실패했습니다. 앱을 닫지 말고 백업해 주세요.');
            throw error;
        } setSaveStatus(storageStatus().durable ? '' : '임시 저장 · 백업 필요', storageStatus().durable ? '' : 'cloud-error'); if (currentUser) {
            if (immediate)
                await pushCloudState();
            else
                cloudTimer = setTimeout(pushCloudState, 1400);
        } };
        if (immediate)
            await run();
        else
            saveTimer = setTimeout(() => run().catch(console.error), 120);
    }
    const views = createViews({
        getState: () => state, getSelectedProjectId: () => selectedProjectId, setSelectedProjectId: (value) => { selectedProjectId = value; },
        getChartMode: () => chartMode, getChartSelection: () => chartSelection, getHomeCashflowMode: () => homeCashflowMode, getHomeYearRange: () => homeYearRange, getHistoryFilter: () => historyFilter, getChartMonth: () => chartMonth, getChartYear: () => chartYear, getHistoryLimit: () => historyLimit, getCashflowMonthKey: () => cashflowMonthKey, getPortfolioGroup: () => portfolioGroup, setPortfolioGroup: (value) => { portfolioGroup = value; }, getCurrentUser: () => currentUser, getAutoBackupStatus: () => autoBackupStatus, getNativeTossStatus: () => nativeTossStatus, getAppUpdateStatus: () => appUpdateStatus, isTossBridgeConfigured,
        activeProjects, projectById, projectRows, computeProject, recoveryStats, totals,
        displayCurrency, fmtMoney, fmtSignedMoney, fmtShares, fmtPct, fmtDate, signClass, projectColors
    });
    const { renderHome, renderProjects, renderGoals, renderSettings } = views;
    function auditLegacyAgainstState(raw, targetState) {
        const project = targetState.projects.find((item) => item.symbol === 'MSTY') || targetState.projects[0];
        if (!project)
            return null;
        const engine = createPortfolioEngine(() => targetState, () => project.id), calc = engine.computeProject(project);
        return buildMigrationAudit(raw, targetState, calc);
    }
    function prepareLegacyMigration(raw) {
        const candidate = migrateLegacy(raw), audit = auditLegacyAgainstState(raw, candidate);
        candidate.meta.migrationAudit = audit;
        candidate.meta.legacyMigrationAvailable = false;
        return { candidate, audit };
    }
    function migrationCheckRows(audit) {
        const labels = { tradeCount: '거래 건수', dividendCount: '배당 건수', splitCount: '분할 건수', shares: '보유주수', costBasis: '남은 취득원가', marketValue: '평가금액', dividendsTotal: '누적배당', reinvestAmount: '재투자 사용액', dividendAvailable: '사용 가능 배당', currentTarget: '현재 목표주수', recoveryBasis: '원금회수 기준' };
        return audit.checks.filter((check) => labels[check.key]).map((check) => `<div class="list-row"><div><div class="row-title">${labels[check.key]}</div><div class="row-sub">V3 ${typeof check.source === 'number' ? round(check.source, 4) : check.source} → V4 ${typeof check.target === 'number' ? round(check.target, 4) : check.target}</div></div><div class="row-value ${check.passed ? 'positive' : 'negative'}">${check.passed ? '일치' : '불일치'}</div></div>`).join('');
    }
    async function previewLegacyMigration() {
        legacyMigrationSource = legacyMigrationSource || await readLegacyState();
        if (!legacyMigrationSource) {
            toast('이 기기에서 V3.2.1 데이터를 찾지 못했습니다.');
            return;
        }
        const preview = prepareLegacyMigration(legacyMigrationSource), audit = preview.audit;
        openModal(`<h3 class="modal-title">V3.2.1 → V4 이전 점검</h3><p class="modal-desc">V3 원본은 읽기만 합니다. 아래 값이 모두 일치할 때 V4 전용 저장소에 복사합니다.</p><div class="list">${migrationCheckRows(audit)}</div><div class="modal-actions"><button class="btn soft" data-close-modal>취소</button><button class="btn primary" id="confirmLegacyMigration" ${audit.passed ? '' : 'disabled'}>일치 확인 후 복사</button></div>`);
        const confirm = document.getElementById('confirmLegacyMigration');
        if (confirm)
            confirm.onclick = async () => { await storageSet(SAFETY_KEY, clone(state)); state = preview.candidate; selectedProjectId = state.projects[0]?.id || ''; await saveState(true); closeModal(); renderAll(); showPage('settings'); toast('V3.2.1 데이터를 V4에 복사했습니다.'); };
    }
    function renderAll(displayOnly = false) {
        const opened = displayOnly ? [...document.querySelectorAll('.goal-step-card[open]')].map(el => el.dataset.goalProject) : [], historyOpen = displayOnly && document.querySelector('.record-center')?.open, scrollY = window.scrollY;
        if (!selectedProjectId)
            selectedProjectId = activeProjects()[0]?.id || '';
        document.getElementById('usdBtn')?.classList.toggle('active', displayCurrency() === 'USD');
        document.getElementById('krwBtn')?.classList.toggle('active', displayCurrency() === 'KRW');
        document.getElementById('usdBtn')?.setAttribute('aria-pressed', String(displayCurrency() === 'USD'));
        document.getElementById('krwBtn')?.setAttribute('aria-pressed', String(displayCurrency() === 'KRW'));
        renderHome();
        renderProjects();
        renderGoals();
        if (!displayOnly)
            renderSettings();
        if (displayOnly) {
            document.querySelectorAll('.goal-step-card').forEach((el) => { el.open = opened.includes(el.dataset.goalProject); });
            const history = document.querySelector('.record-center');
            if (history)
                history.open = !!historyOpen;
            window.scrollTo(0, scrollY);
        }
    }
    function showPage(page) {
        if (!PAGES.includes(page))
            page = 'home';
        currentPage = page;
        document.querySelectorAll('.page').forEach((el) => el.classList.toggle('active', el.id === `page-${page}`));
        document.querySelectorAll('.nav-btn').forEach((el) => el.classList.toggle('active', el.dataset.page === page));
        window.scrollTo({ top: 0, behavior: 'instant' });
        rememberView();
    }
    function openModal(html) {
        const modal = document.getElementById('modal'), backdrop = document.getElementById('modalBackdrop');
        if (!backdrop.classList.contains('show')) {
            modalFocus = document.activeElement;
            modalScroll = window.scrollY;
            document.body.style.position = 'fixed';
            document.body.style.top = `-${modalScroll}px`;
            document.body.style.width = '100%';
        }
        modalDirty = false;
        modal.innerHTML = `<button type="button" class="modal-close" data-close-modal aria-label="닫기">×</button><div class="modal-handle"></div>${html}`;
        modal.querySelectorAll('input,select,textarea').forEach((input, index) => { const label = input.closest('div')?.querySelector('label'); if (label) {
            input.id = 'modal-field-' + index;
            label.htmlFor = input.id;
        } });
        backdrop.classList.add('show');
        modal.scrollTop = 0;
        document.querySelectorAll('main,.bottom-nav').forEach((el) => { el.inert = true; });
        modal.setAttribute('aria-label', modal.querySelector('h3')?.textContent || '입력 창');
        requestAnimationFrame(() => modal.querySelector('button')?.focus());
    }
    function requestCloseModal() {
        if (modalSaving)
            return;
        if (!document.getElementById('modalBackdrop').classList.contains('show'))
            return;
        if (modalDirty) {
            if (!document.querySelector('.modal-unsaved'))
                document.getElementById('modal').insertAdjacentHTML('beforeend', '<div class="modal-unsaved" role="alert"><p>작성 중인 내용이 있습니다. 저장하지 않고 닫을까요?</p><button class="btn soft" data-keep-modal>계속 작성</button><button class="btn danger" data-discard-modal>닫기</button></div>');
            return;
        }
        closeModal();
    }
    function closeModal() {
        if (cloudChoiceResolve) {
            const resolve = cloudChoiceResolve;
            cloudChoiceResolve = null;
            resolve('cancel');
        }
        document.getElementById('modalBackdrop').classList.remove('show');
        document.getElementById('modal').innerHTML = '';
        modalDirty = false;
        document.body.style.position = '';
        document.body.style.top = '';
        document.body.style.width = '';
        document.querySelectorAll('main,.bottom-nav').forEach((el) => { el.inert = false; });
        window.scrollTo(0, modalScroll);
        modalFocus?.focus?.({ preventScroll: true });
    }
    function confirmAction(title, message, action, confirmText = '확인') {
        openModal(`<h3 class="modal-title">${esc(title)}</h3><p class="modal-desc">${esc(message)}</p><div class="modal-actions"><button class="btn soft" data-close-modal>취소</button><button class="btn danger" id="modalConfirm">${esc(confirmText)}</button></div>`);
        document.getElementById('modalConfirm').onclick = async () => { await action(); closeModal(); };
    }
    function openProjectForm(project = null) {
        const edit = !!project, returnPage = currentPage, defaultColor = edit ? n(project.colorIndex) : state.projects.length % PROJECT_COLORS.length;
        const frequencyValue = project?.distributionFrequencyMode === 'manual' ? (project.distributionFrequency || 'monthly') : 'auto';
        openModal(`<h3 class="modal-title">${edit ? '종목 설정' : '종목 추가'}</h3><p class="modal-desc">기록 방식은 같고 종목 성격에 따라 핵심 분석만 달라집니다.</p><form id="projectForm" class="form-grid">
      <div><label class="input-label">티커</label><input class="input" name="symbol" maxlength="12" required value="${esc(project?.symbol || '')}"></div>
      <div class="form-grid two"><div><label class="input-label">운용 성격 <small>분석 화면만 변경</small></label><select class="input select" name="category">${PROJECT_CATEGORIES.map(([key, label]) => `<option value="${key}" ${key === (project?.category || 'dividend') ? 'selected' : ''}>${label}</option>`).join('')}</select></div><div><label class="input-label">목표 주수</label><input class="input" name="targetUnits" type="number" min="0.0001" step="0.0001" required value="${n(project?.targetUnits) || 500}"></div></div>
      <details class="form-advanced"><summary>추가 설정 <span>이름 · 월 계획 · 현재가 · 배당 주기</span></summary><div class="form-grid">
        <div><label class="input-label">종목명</label><input class="input" name="name" value="${esc(project?.name || '')}"></div>
        <div><label class="input-label">프로젝트 이름</label><input class="input" name="tag" value="${esc(project?.tag || '배당 프로젝트')}"></div>
        <div><label class="input-label">월 매수계획 주수</label><input class="input" name="monthlyPlanShares" type="number" min="0" step="0.0001" value="${n(project?.monthlyPlanShares)}"></div>
        <div class="form-grid two"><div><label class="input-label">현재가 USD</label><input class="input" name="currentPrice" type="number" min="0" step="0.0001" value="${n(project?.currentPrice)}"></div><div><label class="input-label">배당 주기</label><select class="input select" name="distributionFrequency"><option value="auto" ${frequencyValue === 'auto' ? 'selected' : ''}>자동 감지</option>${Object.entries(FREQUENCIES).map(([key, spec]) => `<option value="${key}" ${key === frequencyValue ? 'selected' : ''}>${spec.label} 고정</option>`).join('')}</select></div></div>
        <div><label class="input-label">프로젝트 시작일</label><input class="input" name="projectStart" type="date" value="${project?.projectStart || todayISO()}"></div>
        <fieldset class="color-picker"><legend>그래프 식별 색상</legend>${PROJECT_COLORS.map((colors, index) => `<label><input type="radio" name="colorIndex" value="${index}" ${defaultColor === index ? 'checked' : ''}><span class="color-swatch" style="--swatch-a:${colors[0]};--swatch-b:${colors[1]}"></span><b>${PROJECT_COLOR_NAMES[index]}</b></label>`).join('')}</fieldset>
      </div></details>
      <div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">${edit ? '수정 저장' : '추가'}</button></div>
      ${edit && activeProjects().length > 1 ? '<button class="btn soft" type="button" id="archiveProject">프로젝트 보관</button>' : ''}
    </form>`);
        if (returnPage === 'goal')
            document.querySelector('#projectForm .form-advanced').open = true;
        document.getElementById('projectForm').onsubmit = async (event) => {
            event.preventDefault();
            const form = new FormData(event.currentTarget), symbol = String(form.get('symbol')).trim().toUpperCase();
            if (!/^[A-Z0-9.-]{1,16}$/.test(symbol)) {
                toast('티커는 영문·숫자·점·하이픈만 입력해 주세요.');
                return;
            }
            if (state.projects.some((x) => x.id !== project?.id && x.symbol === symbol && !x.archived)) {
                toast('이미 등록된 티커입니다.');
                return;
            }
            const target = project || blankProject(symbol, String(form.get('name')).trim() || symbol);
            const oldSymbol = target.symbol, currentPrice = Math.max(0, n(form.get('currentPrice')));
            const category = PROJECT_CATEGORIES.some(([key]) => key === form.get('category')) ? String(form.get('category')) : 'dividend';
            const frequencyChoice = String(form.get('distributionFrequency'));
            Object.assign(target, { symbol, name: String(form.get('name')).trim() || symbol, tag: String(form.get('tag')).trim() || '배당 프로젝트', category, colorIndex: Math.max(0, Math.min(PROJECT_COLORS.length - 1, Math.floor(n(form.get('colorIndex'))))), targetUnits: Math.max(.0001, n(form.get('targetUnits'))), monthlyPlanShares: Math.max(0, n(form.get('monthlyPlanShares'))), currentPrice, priceSource: currentPrice ? 'manual' : target.priceSource || 'manual', priceUpdatedAt: currentPrice ? new Date().toISOString() : target.priceUpdatedAt || '', distributionFrequencyMode: frequencyChoice === 'auto' ? 'auto' : 'manual', distributionFrequency: FREQUENCIES[frequencyChoice] ? frequencyChoice : (target.distributionFrequency || 'monthly'), projectStart: String(form.get('projectStart')) || todayISO() });
            if (edit && oldSymbol !== symbol)
                tickerChange(target, symbol, todayISO(), uid('ca'));
            if (!edit) {
                historyFilter = {};
                state.projects.push(target);
                selectedProjectId = target.id;
            }
            portfolioGroup = target.category === 'highYield' ? 'highYield' : 'dividend';
            await saveState(true);
            closeModal();
            renderAll(true);
            showPage(edit ? returnPage : 'projects');
            toast(edit ? '프로젝트를 수정했습니다.' : '프로젝트를 추가했습니다.');
        };
        const archive = document.getElementById('archiveProject');
        if (archive)
            archive.onclick = () => confirmAction('프로젝트 보관', `${project.symbol}은 전체 합산에서 숨겨집니다. 기록은 삭제하지 않습니다.`, async () => { project.archived = true; selectedProjectId = activeProjects()[0]?.id || ''; await saveState(true); renderAll(); showPage('projects'); toast('프로젝트를 보관했습니다.'); }, '보관');
    }
    function openTradeForm(record = null) {
        const project = projectById(record?.projectId || selectedProjectId), edit = !!record;
        openModal(`<h3 class="modal-title">${project.symbol} ${edit ? '거래 수정' : '거래 입력'}</h3><p class="modal-desc">모든 원본 금액은 USD로 저장됩니다.</p><form id="tradeForm" class="form-grid">
      <div><label class="input-label">날짜</label><input class="input" name="date" type="date" required value="${record?.date || todayISO()}"></div>
      <div class="form-grid two"><div><label class="input-label">거래</label><select class="input select" name="type"><option value="buy" ${record?.type !== 'sell' ? 'selected' : ''}>매수</option><option value="sell" ${record?.type === 'sell' ? 'selected' : ''}>매도</option></select></div><div data-buy-only><label class="input-label">매수 구분</label><select class="input select" name="buyType"><option value="direct" ${record?.buyType === 'direct' ? 'selected' : ''}>직접매수</option><option value="reinvest" ${record?.buyType === 'reinvest' ? 'selected' : ''}>배당재투자</option><option value="mixed" ${record?.buyType === 'mixed' ? 'selected' : ''}>혼합매수</option><option value="opening" ${record?.buyType === 'opening' ? 'selected' : ''}>초기보유</option></select></div></div>
      <div class="form-grid two"><div><label class="input-label">주수</label><input class="input" name="shares" type="number" min="0.0001" step="0.0001" required value="${n(record?.shares) || 1}"></div><div><label class="input-label">단가 USD</label><input class="input" name="price" type="number" min="0" step="0.0001" required value="${record ? n(record.price) : n(project.currentPrice)}"></div></div>
      <div data-mixed-only><label class="input-label">혼합매수 배당 사용액 USD</label><input class="input" name="reinvestAmountUSD" type="number" min="0" step="0.01" value="${n(record?.reinvestAmountUSD)}"></div>
      <details><summary>추가 정보 (선택)</summary><div><label class="input-label">메모</label><input class="input" name="note" value="${esc(record?.note || '')}"></div></details>
      <div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">저장</button></div>${edit ? `<button class="record-delete-link" type="button" data-delete-from-edit="trade:${record.id}">이 거래 기록 삭제</button>` : ''}</form>`);
        const tradeForm = document.getElementById('tradeForm'), typeInput = tradeForm.elements.type, buyTypeInput = tradeForm.elements.buyType;
        const syncTradeFields = () => { const selling = typeInput.value === 'sell'; tradeForm.querySelector('[data-buy-only]').hidden = selling; tradeForm.querySelector('[data-mixed-only]').hidden = selling || buyTypeInput.value !== 'mixed'; };
        typeInput.onchange = syncTradeFields;
        buyTypeInput.onchange = syncTradeFields;
        syncTradeFields();
        tradeForm.onsubmit = async (event) => { event.preventDefault(); const form = new FormData(event.currentTarget), date = String(form.get('date')), type = form.get('type'), shares = n(form.get('shares')), price = n(form.get('price')), buyType = type === 'sell' ? '' : String(form.get('buyType')), reinvestAmountUSD = buyType === 'mixed' ? n(form.get('reinvestAmountUSD')) : 0; if (!isDate(date) || shares <= 0 || price < 0) {
            toast('날짜·주수·단가를 확인해 주세요.');
            return;
        } if (reinvestAmountUSD > shares * price + .0001) {
            toast('배당 사용액이 총 매수액보다 큽니다.');
            return;
        } const row = record || { id: uid('t'), projectId: project.id, symbol: project.symbol, createdAt: new Date().toISOString() }, before = record ? clone(record) : null; Object.assign(row, { date, type, buyType, shares, price, reinvestAmountUSD, note: String(form.get('note')).trim() }); if (!edit)
            state.trades.push(row); const invalid = computeProject(project).oversells.length; if (invalid) {
            if (edit)
                Object.assign(row, before);
            else
                state.trades = state.trades.filter((item) => item !== row);
            toast('이 거래를 반영하면 해당 날짜의 보유주수보다 많이 매도하게 됩니다.');
            return;
        } await saveState(true); closeModal(); renderAll(true); showPage('projects'); toast(edit ? '거래를 수정했습니다.' : '거래를 저장했습니다.'); };
    }
    function openPriceForm() {
        const project = projectById();
        if (!project)
            return;
        openModal(`<h3 class="modal-title">${esc(project.symbol)} 현재가 수정</h3><p class="modal-desc">평가금액과 목표 매수금 계산에 사용할 현재가입니다.</p><form id="priceForm" class="form-grid"><div><label class="input-label">현재가 USD</label><input class="input" name="price" type="number" min="0.0001" step="0.0001" inputmode="decimal" required value="${n(project.currentPrice) || ''}"></div><div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">저장</button></div></form>`);
        document.getElementById('priceForm').onsubmit = async (event) => { event.preventDefault(); const price = n(new FormData(event.currentTarget).get('price')); if (price <= 0)
            return; project.currentPrice = price; await saveState(true); closeModal(); renderAll(true); toast('현재가를 저장했습니다.'); };
    }
    function openIncomeMonth(month = todayISO().slice(0, 7), projectId = '', symbolFilter = '') {
        if (!/^\d{4}-\d{2}$/.test(month))
            return;
        const date = new Date(month + '-01T12:00:00');
        if (!Number.isFinite(date.getTime()))
            return;
        const shift = (delta) => { const d = new Date(date); d.setMonth(d.getMonth() + delta); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`; };
        const allRows = monthActivity(state, [], month, todayISO()).filter((row) => !row.estimated && (!projectId || row.projectId === projectId)), allActual = allRows.reduce((sum, row) => sum + n(row.amountUSD), 0), project = projectId ? projectById(projectId) : null;
        const bySymbol = [...allRows.reduce((map, row) => { const key = row.symbol || '기타', item = map.get(key) || { symbol: key, value: 0, projectId: row.projectId }; item.value += n(row.amountUSD); map.set(key, item); return map; }, new Map()).values()].sort((a, b) => b.value - a.value), top = bySymbol.slice(0, 4), otherSymbols = new Set(bySymbol.slice(4).map((item) => item.symbol)), other = bySymbol.slice(4).reduce((sum, row) => sum + row.value, 0), composition = other ? [...top, { symbol: '기타', value: other, filter: '__other__' }] : top, total = Math.max(1, allActual);
        const validFilter = symbolFilter && (symbolFilter === '__other__' ? otherSymbols.size : bySymbol.some((item) => item.symbol === symbolFilter)) ? symbolFilter : '', rows = validFilter ? (validFilter === '__other__' ? allRows.filter((row) => otherSymbols.has(row.symbol || '기타')) : allRows.filter((row) => (row.symbol || '기타') === validFilter)) : allRows, actual = rows.reduce((sum, row) => sum + n(row.amountUSD), 0), filterLabel = validFilter === '__other__' ? '기타' : validFilter;
        openModal(`<h3 class="modal-title">${project ? `${esc(project.symbol)} 최근 입금` : '월별 배당'}</h3><div class="month-navigation"><button class="btn soft" data-income-month="${shift(-1)}" ${projectId ? `data-income-project="${esc(projectId)}"` : ''} aria-label="이전 달">‹</button><strong>${month.replace('-', '년 ')}월</strong><button class="btn soft" data-income-month="${shift(1)}" ${projectId ? `data-income-project="${esc(projectId)}"` : ''} aria-label="다음 달">›</button></div>
      <section class="month-actual-summary"><span>${filterLabel ? `${esc(filterLabel)} 실제 세후 입금` : '실제 세후 입금'}</span><strong>${fmtMoney(actual, 2)}</strong><small>${rows.length}회 입금</small></section>
      ${composition.length > 1 ? `<section class="month-composition"><div class="composition-heading"><h4>종목별 구성</h4>${filterLabel ? `<button type="button" data-income-month="${esc(month)}" ${projectId ? `data-income-project="${esc(projectId)}"` : ''}>전체 보기</button>` : '<span>색을 누르면 기록 필터</span>'}</div><div class="composition-bar interactive">${composition.map((item, index) => { const itemProject = projectById(item.projectId), color = itemProject ? projectColors(itemProject)[0] : `hsl(${225 + index * 24} 18% ${55 - index * 3}%)`, filter = item.filter || item.symbol; return `<button type="button" class="${filter === validFilter ? 'active' : validFilter ? 'dimmed' : ''}" style="width:${item.value / total * 100}%;--segment:${color}" data-income-month="${esc(month)}" ${projectId ? `data-income-project="${esc(projectId)}"` : ''} data-income-symbol="${esc(filter)}" aria-label="${esc(item.symbol)} 입금기록만 보기"></button>`; }).join('')}</div><div class="composition-legend interactive">${composition.map((item, index) => { const itemProject = projectById(item.projectId), color = itemProject ? projectColors(itemProject)[0] : `hsl(${225 + index * 24} 18% ${55 - index * 3}%)`, filter = item.filter || item.symbol; return `<button type="button" class="${filter === validFilter ? 'active' : validFilter ? 'dimmed' : ''}" data-income-month="${esc(month)}" ${projectId ? `data-income-project="${esc(projectId)}"` : ''} data-income-symbol="${esc(filter)}"><span><i style="--dot:${color}"></i>${esc(item.symbol)}</span><b>${fmtMoney(item.value, 0)}</b></button>`; }).join('')}</div></section>` : composition.length ? `<p class="single-symbol-note">${esc(composition[0].symbol)} 실제 입금만 있습니다.</p>` : ''}
      <div class="agenda-heading"><h4>${filterLabel ? `${esc(filterLabel)} 입금 기록` : '입금 기록'}</h4><span>${rows.length}건 · 눌러서 상세 보기</span></div><div class="income-agenda">${rows.map((r) => `<button type="button" class="agenda-row agenda-row-button" data-view-record="dividend:${esc(r.id)}"><div><span class="agenda-status actual">완료</span><strong>${esc(r.symbol)} <small>${fmtDate(r.date)}</small></strong></div><div><strong>${fmtMoney(r.amountUSD, 2)}</strong><i>›</i></div></button>`).join('') || '<p class="empty">이 달의 실제 입금 기록이 없습니다.</p>'}</div><button class="btn soft" style="width:100%;margin-top:16px" data-close-modal>닫기</button>`);
    }
    function openDividendForm(record = null, draft = null) {
        const project = projectById(record?.projectId || selectedProjectId), edit = !!record, calc = computeProject(project), returnPage = currentPage;
        openModal(`<h3 class="modal-title">${project.symbol} ${edit ? '배당 수정' : '배당 입력'}</h3><p class="modal-desc">실제로 입금된 세후 배당금을 기록합니다.</p><form id="dividendForm" class="form-grid">
      <div><label class="input-label">지급일</label><input class="input" name="date" type="date" required value="${record?.date || draft?.date || todayISO()}"></div>
      <div><label class="input-label">세후 배당 USD</label><input class="input" name="amountUSD" type="number" min="0.01" step="0.01" required value="${n(record?.amountUSD)}"></div>
      <details class="dividend-extra"><summary>추가 정보 (선택)</summary><p class="tiny muted">지급 기준 주수는 해당 날짜의 거래기록으로 자동 계산됩니다. 필요한 경우에만 고치세요.</p><div class="form-grid">
        <div class="form-grid two"><div><label class="input-label">지급 기준 주수</label><input class="input" name="sharesAtPayment" type="number" min="0" step="0.0001" value="${record ? n(record.sharesAtPayment) : round(sharesAtDate(project.id, draft?.date || todayISO()), 4)}"></div><div><label class="input-label">기준 주가 USD</label><input class="input" name="referencePrice" type="number" min="0" step="0.0001" value="${record ? n(record.referencePrice) : n(project.currentPrice)}"></div></div>
        <div class="form-grid two"><div><label class="input-label">ROC 비율 %</label><input class="input" name="rocPercent" type="number" min="0" max="100" step="0.01" value="${record?.rocPercent ?? ''}"></div><div><label class="input-label">ROC 자료</label><select class="input" name="rocStatus"><option value="estimated" ${record?.rocStatus !== 'final' ? 'selected' : ''}>운용사 추정</option><option value="final" ${record?.rocStatus === 'final' ? 'selected' : ''}>확정 자료</option></select></div></div>
        <div><label class="input-label">메모</label><input class="input" name="note" value="${esc(record?.note || '')}"></div>
      </div></details>
      <div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button>${!edit ? '<button class="btn soft" type="submit" name="next" value="1">저장 후 계속</button>' : ''}<button class="btn primary" type="submit">저장</button></div>${edit ? `<button class="record-delete-link" type="button" data-delete-from-edit="dividend:${record.id}">이 배당 기록 삭제</button>` : ''}</form>`);
        const dividendForm = document.getElementById('dividendForm'), preview = document.createElement('div');
        preview.className = 'dividend-preview';
        preview.setAttribute('aria-live', 'polite');
        dividendForm.querySelector('.modal-actions').before(preview);
        const updatePreview = () => { const form = new FormData(dividendForm), amount = n(form.get('amountUSD')), shares = n(form.get('sharesAtPayment')); if (amount <= 0) {
            preview.textContent = '실제 입금액을 입력하면 주당 실수령액을 확인할 수 있습니다.';
            return;
        } preview.innerHTML = `<strong>이번 실제 입금</strong><br>${fmtMoney(amount, 2)}${shares > 0 ? ` · 주당 ${fmtMoney(amount / shares, 4)}` : ''}<br><span class="tiny muted">월·연 예상으로 늘리지 않고 실제 입금값만 저장합니다.</span>`; };
        if (!edit)
            dividendForm.elements.date.addEventListener('change', () => { dividendForm.elements.sharesAtPayment.value = round(sharesAtDate(project.id, dividendForm.elements.date.value), 4); updatePreview(); });
        dividendForm.addEventListener('input', updatePreview);
        updatePreview();
        dividendForm.onsubmit = async (event) => {
            event.preventDefault();
            if (modalSaving)
                return;
            const form = new FormData(dividendForm), date = String(form.get('date')), amountUSD = n(form.get('amountUSD'));
            if (!isDate(date) || amountUSD <= 0) {
                toast('지급일과 배당금을 확인해 주세요.');
                return;
            }
            const keepEntering = !edit && event.submitter?.name === 'next', before = record ? clone(record) : null;
            const row = record || { id: uid('d'), projectId: project.id, symbol: project.symbol, createdAt: new Date().toISOString() };
            Object.assign(row, { date, amountUSD, rocPercent: form.get('rocPercent') === '' ? null : n(form.get('rocPercent')), rocStatus: form.get('rocStatus') === 'final' ? 'final' : 'estimated', sharesAtPayment: Math.max(0, n(form.get('sharesAtPayment'))), referencePrice: Math.max(0, n(form.get('referencePrice'))), note: String(form.get('note')).trim() });
            if (!edit)
                state.dividends.push(row);
            const controls = [...document.getElementById('modal').querySelectorAll('input,select,button')], disabled = controls.map((el) => el.disabled);
            modalSaving = true;
            dividendForm.setAttribute('aria-busy', 'true');
            controls.forEach((el) => el.disabled = true);
            preview.textContent = '저장 중…';
            try {
                await saveState(true);
            }
            catch (error) {
                if (edit)
                    Object.assign(row, before);
                else
                    state.dividends = state.dividends.filter((item) => item !== row);
                controls.forEach((el, i) => el.disabled = disabled[i]);
                dividendForm.removeAttribute('aria-busy');
                modalSaving = false;
                updatePreview();
                return;
            }
            modalSaving = false;
            if (keepEntering) {
                renderAll(true);
                openDividendForm(null, { date });
                toast('저장했습니다. 다음 금액을 입력하세요.');
                return;
            }
            closeModal();
            renderAll(true);
            showPage(returnPage);
            toast(edit ? '배당을 수정했습니다.' : '배당을 저장했습니다.');
        };
        if (draft)
            requestAnimationFrame(() => { dividendForm.elements.amountUSD.focus(); dividendForm.elements.amountUSD.select(); });
    }
    function openCashForm(record = null) {
        const project = projectById(record?.projectId || selectedProjectId), edit = !!record;
        openModal(`<h3 class="modal-title">${project.symbol} 잔액 ${edit ? '수정' : '보정'}</h3><p class="modal-desc">실제 사용 가능 배당과 앱 잔액이 다를 때만 더하거나 뺍니다.</p><form id="cashForm" class="form-grid"><div><label class="input-label">날짜</label><input class="input" name="date" type="date" value="${record?.date || todayISO()}" required></div><div><label class="input-label">보정액 USD (+/−)</label><input class="input" name="amountUSD" type="number" step="0.01" value="${n(record?.amountUSD)}" required></div><div><label class="input-label">사유</label><input class="input" name="label" value="${esc(record?.label || '잔액 보정')}" required></div><div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">저장</button></div>${edit ? `<button class="record-delete-link" type="button" data-delete-from-edit="cash:${record.id}">이 보정 기록 삭제</button>` : ''}</form>`);
        document.getElementById('cashForm').onsubmit = async (event) => { event.preventDefault(); const form = new FormData(event.currentTarget), date = String(form.get('date')), amountUSD = n(form.get('amountUSD')); if (!isDate(date) || !amountUSD) {
            toast('날짜와 0이 아닌 보정액을 입력해 주세요.');
            return;
        } const row = record || { id: uid('c'), projectId: project.id, symbol: project.symbol, createdAt: new Date().toISOString() }; Object.assign(row, { date, amountUSD, label: String(form.get('label')).trim() || '잔액 보정' }); if (!edit)
            state.cashAdjustments.push(row); await saveState(true); closeModal(); renderAll(); showPage('projects'); toast('잔액 보정을 저장했습니다.'); };
    }
    function openWithdrawalForm(projectId = selectedProjectId, record = null) {
        const project = projectById(record?.projectId || projectId), calc = computeProject(project), edit = !!record, recovery = project.recovery || {}, available = Math.max(0, calc.dividendAvailable + (edit ? Math.abs(n(record.amountUSD)) : 0)), returnPage = currentPage;
        if (!recovery.locked) {
            toast('원금회수 기준을 먼저 확정해 주세요.');
            return;
        }
        openModal(`<h3 class="modal-title">${project.symbol} 배당 인출 ${edit ? '수정' : '기록'}</h3><p class="modal-desc">실제로 계좌 밖으로 뺀 배당금만 기록합니다. 배당 입금이나 재투자는 원금회수로 계산하지 않습니다.</p><form id="withdrawalForm" class="form-grid"><div class="record-detail-grid"><div><span>사용 가능 배당</span><strong>${fmtMoney(available, 2)}</strong></div><div><span>남은 원금</span><strong>${fmtMoney(recoveryStats(calc).remaining, 2)}</strong></div></div><div><label class="input-label">인출일</label><input class="input" name="date" type="date" min="${recovery.startDate}" value="${record?.date || todayISO()}" required></div><div><label class="input-label">실제 인출액 USD</label><input class="input" name="amountUSD" type="number" min="0.01" max="${Math.max(.01, round(available, 2))}" step="0.01" value="${edit ? Math.abs(n(record.amountUSD)) : ''}" required></div><div><label class="input-label">메모</label><input class="input" name="note" value="${esc(record?.note || '')}" placeholder="예: 생활비 계좌로 이체"></div><div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">저장</button></div>${edit ? `<button class="record-delete-link" type="button" data-delete-from-edit="cash:${record.id}">이 인출 기록 삭제</button>` : ''}</form>`);
        document.getElementById('withdrawalForm').onsubmit = async (event) => { event.preventDefault(); const form = new FormData(event.currentTarget), date = String(form.get('date')), amount = n(form.get('amountUSD')); if (!isDate(date) || date < recovery.startDate || amount <= 0) {
            toast('회수 시작일 이후의 인출 날짜와 금액을 확인해 주세요.');
            return;
        } if (amount > available + .005) {
            toast('사용 가능한 배당금보다 많이 인출할 수 없습니다.');
            return;
        } const row = record || { id: uid('w'), projectId: project.id, symbol: project.symbol, createdAt: new Date().toISOString() }; Object.assign(row, { date, amountUSD: -amount, purpose: 'recoveryWithdrawal', label: '배당금 인출', note: String(form.get('note')).trim() }); if (!edit)
            state.cashAdjustments.push(row); await saveState(true); closeModal(); renderAll(); showPage(returnPage === 'goal' ? 'goal' : 'projects'); toast(edit ? '인출 기록을 수정했습니다.' : '실제 인출액을 원금회수에 반영했습니다.'); };
    }
    function openSplitForm(record = null) {
        const project = projectById(record?.projectId || selectedProjectId), edit = !!record;
        openModal(`<h3 class="modal-title">${project.symbol} 분할·역분할</h3><p class="modal-desc">예: 2주가 1주가 되면 2 → 1입니다. 보유·평균단가·목표가 함께 조정됩니다.</p><form id="splitForm" class="form-grid"><div><label class="input-label">기준일</label><input class="input" name="date" type="date" value="${record?.date || todayISO()}" required></div><div class="form-grid two"><div><label class="input-label">기존 주수</label><input class="input" name="from" type="number" min="0.0001" step="0.0001" value="${n(record?.from) || 2}" required></div><div><label class="input-label">변경 주수</label><input class="input" name="to" type="number" min="0.0001" step="0.0001" value="${n(record?.to) || 1}" required></div></div><div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">적용</button></div>${edit ? `<button class="record-delete-link" type="button" data-delete-from-edit="split:${record.id}">이 분할 기록 삭제</button>` : ''}</form>`);
        document.getElementById('splitForm').onsubmit = async (event) => { event.preventDefault(); const form = new FormData(event.currentTarget), date = String(form.get('date')), from = n(form.get('from')), to = n(form.get('to')); if (!isDate(date) || from <= 0 || to <= 0) {
            toast('분할 날짜와 비율을 확인해 주세요.');
            return;
        } const row = record || { id: uid('s'), projectId: project.id, symbol: project.symbol, createdAt: new Date().toISOString() }, before = record ? clone(record) : null; Object.assign(row, { date, from, to, type: to < from ? 'reverse' : 'forward' }); if (!edit)
            state.splits.push(row); if (computeProject(project).oversells.length) {
            if (edit)
                Object.assign(row, before);
            else
                state.splits = state.splits.filter((item) => item !== row);
            toast('이 분할을 반영하면 이후 매도 기록이 보유주수를 초과합니다.');
            return;
        } await saveState(true); closeModal(); renderAll(); showPage('projects'); toast('분할 비율을 반영했습니다.'); };
    }
    function recordByToken(token) {
        const [kind, id] = String(token).split(':');
        const key = { trade: 'trades', dividend: 'dividends', split: 'splits', cash: 'cashAdjustments' }[kind];
        return { kind, key, row: key ? state[key].find((x) => String(x.id) === id) : null };
    }
    function openRecordDetail(token) {
        const { kind, row } = recordByToken(token);
        if (!row)
            return;
        const project = projectById(row.projectId), withdrawal = kind === 'cash' && row.purpose === 'recoveryWithdrawal', labels = { trade: '거래 기록', dividend: '배당 기록', cash: withdrawal ? '배당 인출 기록' : '잔액 보정', split: '분할 기록' };
        const fromToss = row.source?.provider === 'toss';
        if (kind === 'dividend') {
            const sourceLabel = fromToss ? '토스 동기화 기록' : '직접 입력 기록';
            const note = row.note && !/^더미\s/.test(String(row.note)) ? `<p class="record-note">${esc(row.note)}</p>` : '';
            const action = fromToss ? '<p class="record-source-note">동기화 원본은 앱에서 수정하지 않습니다.</p>' : `<button class="record-edit-link" type="button" data-edit-record="${esc(token)}">직접 입력값 고치기</button>`;
            openModal(`<div class="record-detail-head"><div><span>${esc(project?.symbol || row.symbol || '')} · 세후 배당</span><h3 class="modal-title">${fmtDate(row.date)} 입금</h3></div><b class="record-source-badge ${fromToss ? 'synced' : 'manual'}">${sourceLabel}</b></div><div class="record-primary-value"><span>실제 입금액</span><strong>${fmtMoney(row.amountUSD, 2)}</strong></div><div class="record-detail-grid compact"><div><span>지급 기준 주수</span><strong>${n(row.sharesAtPayment) > 0 ? fmtShares(row.sharesAtPayment) + '주' : '기록 없음'}</strong></div></div>${note}${action}<button class="btn primary record-close" data-close-modal>닫기</button>`);
            return;
        }
        let details = '';
        if (kind === 'trade')
            details = `<div><span>거래</span><strong>${row.type === 'sell' ? '매도' : '매수'} · ${fmtShares(row.shares)}주</strong></div><div><span>단가</span><strong>${fmtMoney(row.price)}</strong></div><div><span>거래금액</span><strong>${fmtMoney(n(row.shares) * n(row.price))}</strong></div>`;
        if (kind === 'dividend')
            details = `<div><span>세후 배당</span><strong>${fmtMoney(row.amountUSD, 2)}</strong></div><div><span>지급 기준 주수</span><strong>${n(row.sharesAtPayment) > 0 ? fmtShares(row.sharesAtPayment) + '주' : '기록 없음'}</strong></div>`;
        if (kind === 'cash')
            details = withdrawal ? `<div><span>실제 인출액</span><strong>${fmtMoney(Math.abs(n(row.amountUSD)), 2)}</strong></div><div><span>원금회수 반영</span><strong>포함</strong></div>` : `<div><span>보정액</span><strong>${fmtSignedMoney(row.amountUSD)}</strong></div><div><span>사유</span><strong>${esc(row.label || '잔액 보정')}</strong></div>`;
        if (kind === 'split')
            details = `<div><span>변경 비율</span><strong>${n(row.from)} → ${n(row.to)}</strong></div>`;
        const management = fromToss ? '<p class="record-source-note">토스 원본 기록은 이 앱에서 수정하지 않습니다.</p>' : `<details class="record-manage"><summary>기록 관리</summary><div><p>직접 입력한 값이 잘못된 경우에만 고치세요.</p><button class="btn soft small" data-edit-record="${esc(token)}">직접 입력값 고치기</button></div></details>`;
        openModal(`<h3 class="modal-title">${esc(project?.symbol || row.symbol || '')} ${labels[kind] || '기록'}</h3><p class="modal-desc">${fmtDate(row.date)}${fromToss ? ' · 토스에서 가져온 기록' : ''}</p><div class="record-detail-grid">${details}</div>${row.note ? `<p class="record-note">${esc(row.note)}</p>` : ''}${management}<button class="btn primary record-close" data-close-modal>닫기</button>`);
    }
    function editRecord(token) { const { kind, row } = recordByToken(token); if (!row)
        return; if (row.source?.provider === 'toss') {
        toast('토스 동기화 원본은 수정할 수 없습니다.');
        return;
    } if (kind === 'trade')
        openTradeForm(row); if (kind === 'dividend')
        openDividendForm(row); if (kind === 'cash' && row.purpose === 'recoveryWithdrawal')
        openWithdrawalForm(row.projectId, row);
    else if (kind === 'cash')
        openCashForm(row); if (kind === 'split')
        openSplitForm(row); }
    function deleteRecord(token) { const { key, row } = recordByToken(token); if (!row)
        return; if (row.source?.provider === 'toss') {
        toast('토스 동기화 원본은 삭제할 수 없습니다.');
        return;
    } confirmAction('기록 삭제', `${fmtDate(row.date)} 기록을 삭제합니다.`, async () => { await storageSet(SAFETY_KEY, clone(state)); const previous = state[key]; state[key] = state[key].filter((x) => x.id !== row.id); if ((key === 'trades' || key === 'splits') && computeProject(row.projectId).oversells.length) {
        state[key] = previous;
        toast('이 기록을 삭제하면 이후 매도가 보유주수를 초과하므로 삭제하지 않았습니다.');
        return;
    } await saveState(true); renderAll(); showPage('projects'); toast('기록을 삭제했습니다.'); }, '삭제'); }
    function projectIssues(projectId = null) {
        const projects = projectId ? [projectById(projectId)] : state.projects, issues = [];
        for (const project of projects.filter(Boolean)) {
            const calc = computeProject(project), prefix = `${project.symbol}: `;
            if (calc.oversells.length)
                issues.push(`${prefix}보유량 초과 매도 ${calc.oversells.length}건`);
            if (calc.cashDeficitEvents.length)
                issues.push(`${prefix}날짜순 배당 원장에서 잔액 부족 ${calc.cashDeficitEvents.length}건 · 최대 ${fmtMoney(Math.abs(calc.minDividendBalance))}`);
            if (!calc.priceAvailable && calc.shares > 0)
                issues.push(`${prefix}현재가 미입력으로 평가금액·총손익 계산 대기`);
            const futureCount = ['trades', 'dividends', 'splits', 'cashAdjustments'].reduce((count, key) => count + projectRows(key, project.id).filter((row) => String(row.date) > todayISO()).length, 0);
            if (futureCount)
                issues.push(`${prefix}현재 계산에서 제외된 미래 날짜 기록 ${futureCount}건`);
            const badTrade = calc.trades.filter((x) => !isDate(x.date) || n(x.shares) <= 0 || n(x.price) < 0);
            if (badTrade.length)
                issues.push(`${prefix}잘못된 거래 ${badTrade.length}건`);
            const badDividend = calc.dividends.filter((x) => !isDate(x.date) || n(x.amountUSD) <= 0);
            if (badDividend.length)
                issues.push(`${prefix}잘못된 배당 ${badDividend.length}건`);
            const badSplit = projectRows('splits', project.id).filter((x) => !isDate(x.date) || n(x.from) <= 0 || n(x.to) <= 0);
            if (badSplit.length)
                issues.push(`${prefix}잘못된 분할 ${badSplit.length}건`);
            const tradeKeys = new Set();
            let duplicates = 0;
            calc.trades.forEach((x) => { const key = [x.date, x.type, x.buyType, n(x.shares).toFixed(8), n(x.price).toFixed(8)].join('|'); if (tradeKeys.has(key))
                duplicates++; tradeKeys.add(key); });
            if (duplicates)
                issues.push(`${prefix}중복 가능 거래 ${duplicates}건`);
            const dividendKeys = new Set();
            let duplicateDividends = 0;
            calc.dividends.forEach((x) => { const key = [x.date, n(x.amountUSD).toFixed(2), n(x.sharesAtPayment).toFixed(4)].join('|'); if (dividendKeys.has(key))
                duplicateDividends++; dividendKeys.add(key); });
            if (duplicateDividends)
                issues.push(`${prefix}중복 가능 배당 ${duplicateDividends}건`);
        }
        return issues;
    }
    function showIssues(projectId = null) { const issues = projectIssues(projectId); openModal(`<h3 class="modal-title">${projectId ? '프로젝트' : '전체'} 점검</h3>${issues.length ? `<div class="check-list">${issues.map((x) => `<div class="check-item">${esc(x)}</div>`).join('')}</div>` : '<div class="check-ok">오류가 발견되지 않았습니다.</div>'}<button class="btn primary" style="width:100%;margin-top:14px" data-close-modal>확인</button>`); }
    function lockRecovery(projectId, editing = false) {
        const calc = computeProject(projectId), project = calc.project;
        const basis = editing && project.recovery?.locked ? n(project.recovery.basis) : calc.targetBasisSuggestion, startDate = editing && project.recovery?.locked ? project.recovery.startDate : (calc.targetReachedDate || todayISO());
        openModal(`<h3 class="modal-title">${project.symbol} 원금회수 기준 ${editing ? '수정' : '확정'}</h3><p class="modal-desc">목표 달성 시점까지 직접 넣은 순투입 원금을 고정합니다. 이후에는 실제로 계좌 밖으로 인출한 배당금만 회수액으로 계산합니다.</p><form id="recoveryForm" class="form-grid"><div><label class="input-label">기준원금 USD</label><input class="input" name="basis" type="number" min="0.01" step="0.01" required value="${round(basis, 2)}"></div><div><label class="input-label">회수 시작일</label><input class="input" name="startDate" type="date" required value="${startDate}"></div><div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">${editing ? '수정 저장' : '확정'}</button></div></form>`);
        document.getElementById('recoveryForm').onsubmit = async (event) => { event.preventDefault(); const form = new FormData(event.currentTarget), nextBasis = n(form.get('basis')), nextStartDate = String(form.get('startDate')); if (nextBasis <= 0 || !isDate(nextStartDate)) {
            toast('기준원금과 시작일을 확인해 주세요.');
            return;
        } project.recovery = { locked: true, basis: nextBasis, startDate: nextStartDate, targetReachedDate: project.recovery?.targetReachedDate || calc.targetReachedDate || nextStartDate, calculatedBasisAtLock: calc.targetBasisSuggestion, confirmedAt: new Date().toISOString(), method: 'withdrawnOnly' }; await saveState(true); closeModal(); renderAll(); showPage('goal'); toast(editing ? '원금회수 기준을 수정했습니다.' : '원금회수 단계를 시작했습니다.'); };
    }
    function downloadFile(filename, content, type = 'application/octet-stream') { const blob = content instanceof Blob ? content : new Blob([content], { type }); const url = URL.createObjectURL(blob), a = document.createElement('a'); a.href = url; a.download = filename; document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(url), 1500); }
    let backupRunning = false, backupObjectUrl = '', preparedBackup = null, preparedBackupFilename = '';
    async function saveBackupToChosenLocation() {
        if (!preparedBackup || !preparedBackupFilename) {
            toast('백업을 다시 준비해 주세요.');
            return;
        }
        try {
            const picker = window.showSaveFilePicker;
            if (typeof picker === 'function') {
                const handle = await picker({ suggestedName: preparedBackupFilename, types: [{ description: 'DividendOS ZIP 백업', accept: { 'application/zip': ['.zip'] } }] });
                const writable = await handle.createWritable();
                await writable.write(preparedBackup);
                await writable.close();
                closeModal();
                toast('선택한 위치에 ZIP 백업을 저장했습니다.');
                return;
            }
            const file = new File([preparedBackup], preparedBackupFilename, { type: 'application/zip' }), nav = navigator;
            if (typeof nav.share === 'function' && typeof nav.canShare === 'function' && nav.canShare({ files: [file] })) {
                await nav.share({ files: [file], title: 'DividendOS 백업' });
                closeModal();
                toast('선택한 앱으로 ZIP 백업을 전달했습니다.');
                return;
            }
            downloadFile(preparedBackupFilename, preparedBackup, 'application/zip');
            closeModal();
            toast('다운로드 폴더에 ZIP 백업을 저장했습니다.');
        }
        catch (error) {
            if (error?.name === 'AbortError')
                return;
            console.error(error);
            toast('위치 선택 저장에 실패했습니다. 아래 다운로드 저장을 사용해 주세요.');
        }
    }
    async function downloadBackup() {
        if (backupRunning)
            return;
        backupRunning = true;
        openModal('<h3 class="modal-title">백업 준비</h3><p class="modal-desc" role="status">앱과 기록을 ZIP으로 묶고 있습니다.</p>');
        try {
            const zip = await buildPortableBackup(clone(state));
            if (backupObjectUrl)
                URL.revokeObjectURL(backupObjectUrl);
            backupObjectUrl = URL.createObjectURL(zip);
            const stamp = new Date().toISOString().replace(/[-:]/g, '').replace(/\\.\\d{3}Z$/, 'Z').replace('T', '_'), filename = `DividendOS_v${APP_VERSION}_${stamp}.zip`;
            preparedBackup = zip;
            preparedBackupFilename = filename;
            openModal(`<h3 class="modal-title">백업 준비 완료</h3><p class="modal-desc">종목 ${state.projects.length}개 · 거래 ${state.trades.length}건 · 배당 ${state.dividends.length}건<br>저장 위치를 직접 선택하거나 다운로드 폴더에 바로 저장할 수 있습니다.</p><div class="form-grid"><button class="btn primary backup-download" data-backup-save>저장 위치 선택</button><a class="btn soft backup-download" href="${backupObjectUrl}" download="${filename}">다운로드 폴더에 저장</a></div><p class="detail-note">기기에서 위치 선택을 지원하지 않으면 공유 화면 또는 기본 다운로드로 안전하게 전환됩니다.</p>`);
            state.meta.lastBackupAt = new Date().toISOString();
            await saveState(true);
        }
        catch (error) {
            console.error(error);
            openModal('<h3 class="modal-title">백업 준비 실패</h3><p class="modal-desc">기록은 그대로 유지됩니다. 연결 상태를 확인하고 다시 시도해 주세요.</p>');
        }
        finally {
            backupRunning = false;
        }
    }
    async function restoreFromFile(file) {
        try {
            const parsed = await readStateFromBackupFile(file);
            if (Number(parsed.schemaVersion) >= DATA_SCHEMA_VERSION) {
                const rawIssues = validateLedger(parsed);
                if (rawIssues.length)
                    throw new Error(rawIssues.join(' '));
            }
            const restored = migrate(parsed), issues = validateLedger(restored);
            if (issues.length)
                throw new Error(issues.join(' '));
            const engine = createPortfolioEngine(() => restored, () => restored.projects[0].id);
            if (engine.totals().rows.some((c) => c.oversells.length))
                throw new Error('보유량을 초과하는 매도 기록이 있습니다.');
            openModal(`<h3 class="modal-title">백업 복원 확인</h3><p class="modal-desc">종목 ${restored.projects.length}개 · 거래 ${restored.trades.length}건 · 배당 ${restored.dividends.length}건<br>현재 V4 기록을 교체합니다. 현재 기록은 기기에 안전 복사하며 기존 MSTY 원본은 건드리지 않습니다.</p><div class="modal-actions"><button class="btn soft" data-close-modal>취소</button><button class="btn primary" id="confirmRestore">확인 후 복원</button></div>`);
            document.getElementById('confirmRestore').onclick = async () => { const previousProjectId = selectedProjectId; await storageSet(SAFETY_KEY, clone(state)); state = restored; selectedProjectId = activeProjects().some((project) => project.id === previousProjectId) ? previousProjectId : (activeProjects()[0]?.id || ''); await saveState(true); closeModal(); renderAll(); showPage('home'); toast('대조를 통과한 백업을 복원했습니다.'); };
        }
        catch (error) {
            toast(error?.message || '지원되는 DividendOS ZIP이 아닙니다.');
        }
    }
    async function restoreSafetyCopy() {
        const previous = await storageGet(SAFETY_KEY);
        if (!previous) {
            toast('되돌릴 안전 사본이 없습니다.');
            return;
        }
        const restored = migrate(previous), issues = validateLedger(restored);
        if (issues.length) {
            toast('안전 사본을 확인할 수 없습니다. ZIP 백업을 사용해 주세요.');
            return;
        }
        confirmAction('직전 안전 사본 복원', `종목 ${restored.projects.length}개 · 거래 ${restored.trades.length}건 · 배당 ${restored.dividends.length}건으로 되돌립니다. 현재 기록도 안전 사본으로 보관합니다.`, async () => {
            const previousProjectId = selectedProjectId;
            await storageSet(SAFETY_KEY, clone(state));
            state = restored;
            selectedProjectId = activeProjects().some((project) => project.id === previousProjectId) ? previousProjectId : (activeProjects()[0]?.id || '');
            await saveState(true);
            renderAll();
            showPage('home');
            toast('직전 안전 사본으로 복원했습니다.');
        }, '되돌리기');
    }
    async function restoreLatestAutoBackup() {
        const entries = await refreshAutoBackupStatus();
        if (!entries.length) {
            toast('자동 백업이 없습니다.');
            return;
        }
        const backup = await readAutoBackup(backupStorage, entries[0].id), restored = migrate(backup?.state), issues = validateLedger(restored);
        if (!backup || issues.length) {
            toast('자동 백업을 확인할 수 없습니다.');
            return;
        }
        confirmAction('최근 자동 백업 복원', `${entries[0].createdAt.slice(0, 16).replace('T', ' ')} 기록으로 되돌립니다. 현재 기록도 먼저 안전 복사합니다.`, async () => { await storageSet(SAFETY_KEY, clone(state)); state = restored; selectedProjectId = activeProjects()[0]?.id || ''; await saveState(true); renderAll(); showPage('home'); toast('최근 자동 백업을 복원했습니다.'); }, '복원');
    }
    function exportCSV() { downloadFile(`DividendOS_CSV_${todayISO().replaceAll('-', '')}.zip`, buildCsvExportZip(state)); toast('종목·거래·배당·목표 CSV 4개를 저장했습니다.'); }
    async function chooseInitialSync(cloudState) {
        const localHas = hasMeaningfulData(state), cloudHas = hasMeaningfulData(cloudState);
        const signature = (value) => JSON.stringify(['projects', 'trades', 'dividends', 'splits', 'cashAdjustments', 'settings'].map(key => value?.[key]));
        if (cloudHas) {
            if (localHas && signature(state) !== signature(cloudState))
                return await new Promise(resolve => {
                    openModal(`<h3 class="modal-title">동기화할 데이터 선택</h3><p class="modal-desc">기기와 클라우드 기록이 다릅니다. 날짜만으로 자동 덮어쓰지 않습니다.<br>기기: 거래 ${state.trades.length}건 · 배당 ${state.dividends.length}건<br>클라우드: 거래 ${cloudState.trades.length}건 · 배당 ${cloudState.dividends.length}건<br>닫으면 기기 기록을 유지하고 동기화를 보류합니다.</p><div class="form-grid"><button class="btn primary" id="useLocal">기기 기록 저장</button><button class="btn secondary" id="useCloud">클라우드 불러오기</button></div>`);
                    cloudChoiceResolve = resolve;
                    for (const [id, choice] of [['useLocal', 'local'], ['useCloud', 'cloud']])
                        document.getElementById(id).onclick = () => { cloudChoiceResolve = null; closeModal(); resolve(choice); };
                });
            return 'cloud';
        }
        return localHas ? 'local' : 'blank';
    }
    async function connectCloudForUser(user) {
        currentUser = user;
        cloudReady = false;
        cloudUnsubscribe?.();
        cloudUnsubscribe = null;
        setSaveStatus('동기화 확인', 'cloud-busy');
        try {
            let cloudData = await getCloudDocument(user.uid), cloudState = cloudData?.state ? migrate(cloudData.state) : null, usingLegacyCloud = false, usingSingleDocument = !!cloudData?.legacySingleDocument;
            cloudRevision = Math.max(0, n(cloudData?.revision));
            if (!cloudState) {
                const legacy = await getLegacyCloudDocument(user.uid);
                if (legacy?.state) {
                    legacyMigrationSource = legacy.state;
                    cloudState = prepareLegacyMigration(legacy.state).candidate;
                    usingLegacyCloud = true;
                }
            }
            else if (!cloudState.meta?.migrationAudit) {
                const legacy = await getLegacyCloudDocument(user.uid);
                if (legacy?.state) {
                    legacyMigrationSource = legacy.state;
                    const audit = auditLegacyAgainstState(legacy.state, cloudState);
                    if (audit?.passed)
                        cloudState.meta.migrationAudit = audit;
                    else
                        cloudState.meta.legacyMigrationAvailable = true;
                }
            }
            const choice = await chooseInitialSync(cloudState);
            if (choice === 'cancel') {
                pendingCloudState = cloudState;
                setSaveStatus('동기화 보류', 'cloud-error');
                return;
            }
            if (cloudState) {
                const issues = validateLedger(cloudState);
                if (issues.length)
                    throw new Error(issues.join(' '));
            }
            pendingCloudState = null;
            if (choice === 'cloud' && cloudState) {
                await storageSet(SAFETY_KEY, clone(state));
                await storageSet(STATE_KEY, cloudState);
                state = cloudState;
                cloudReady = true;
                if (usingLegacyCloud || usingSingleDocument)
                    await pushCloudState();
            }
            else {
                cloudReady = true;
                await pushCloudState();
            }
            selectedProjectId = activeProjects()[0]?.id || '';
            renderAll();
            showPage(currentPage);
            document.getElementById('authGate')?.classList.add('hidden');
            cloudUnsubscribe = await subscribeCloudDocument(user.uid, (data) => {
                if (!data?.state || applyingCloudState || cloudWritePending || n(data.revision) <= cloudRevision)
                    return;
                const remote = migrate(data.state);
                pendingCloudState = remote;
                cloudRevision = n(data.revision);
                cloudReady = false;
                clearTimeout(cloudTimer);
                autoBackup('remote-conflict');
                setSaveStatus('다른 기기 변경 · 확인 필요', 'cloud-error');
                toast('기록을 자동 교체하지 않았습니다. 설정에서 클라우드 기록 확인을 눌러 주세요.');
                renderAll();
            }, (error) => { console.error(error); cloudReady = false; setSaveStatus('동기화 오류', 'cloud-error'); });
            setSaveStatus('', 'cloud-ok');
        }
        catch (error) {
            cloudReady = false;
            clearTimeout(cloudTimer);
            console.error(error);
            setSaveStatus('연결 오류', 'cloud-error');
            document.getElementById('authGate')?.classList.add('hidden');
            toast('클라우드 연결에 실패했습니다. 기기 저장으로 사용할 수 있습니다.');
        }
    }
    async function initAuth() { await initGoogleAuth({ loginButtonId: 'googleLoginBtn', statusElementId: 'authGateStatus', onSignedIn: connectCloudForUser, onSignedOut: () => { currentUser = null; cloudRevision = 0; cloudUnsubscribe?.(); cloudUnsubscribe = null; setSaveStatus(''); document.getElementById('authGate')?.classList.add('hidden'); }, onError: (message) => toast(message, { haptic: true }) }); }
    function refreshTossComparisons() {
        const toss = state.integrations.toss;
        toss.comparisons = (toss.comparisons || []).map((row) => {
            const project = findProjectForToss(row);
            const appShares = project ? computeProject(project).shares : 0;
            return { ...row, appShares, difference: n(row.shares) - appShares };
        });
    }
    function adoptMatchingTossDividends() {
        const toss = state.integrations.toss, adoptedIds = new Set();
        let adopted = 0;
        for (const adoption of automaticTossDividendAdoptions(toss.dividendCandidates || [])) {
            const row = adoption.candidate;
            const dividend = state.dividends.find((item) => item.id === adoption.manualId && item.source?.provider !== 'toss');
            if (!dividend)
                continue;
            dividend.source = { provider: 'toss', externalId: row.externalId, rawExternalId: row.rawExternalId, sourceIdKind: row.sourceIdKind, sourceFingerprint: row.sourceFingerprint, accountId: row.accountId, assetKey: row.assetKey, market: row.market, securityId: row.securityId, importedAt: new Date().toISOString(), adoptedManual: true };
            adoptedIds.add(String(row.externalId || ''));
            adopted++;
        }
        if (adoptedIds.size)
            toss.dividendCandidates = (toss.dividendCandidates || []).filter((row) => !adoptedIds.has(String(row?.externalId || '')));
        return adopted;
    }
    async function tryAutomaticTossImport() {
        const plan = automaticTossImportPlan(state.integrations.toss);
        if (!plan.eligible)
            return { imported: 0, reason: plan.reason };
        const before = clone(state), importedTradeIds = new Set(), importedDividendIds = new Set(), affectedProjectIds = new Set();
        let buys = 0, sells = 0, dividends = 0;
        try {
            for (const row of plan.candidates) {
                const normalized = normalizeTossOrder(row);
                if (!normalized || normalized.currency !== 'USD')
                    throw new Error('invalid-candidate');
                let project = findProjectForToss(normalized, { attach: true });
                if (!project) {
                    project = blankProject(normalized.symbol, normalized.name);
                    project.colorIndex = state.projects.length % PROJECT_COLORS.length;
                    state.projects.push(project);
                }
                findProjectForToss(normalized, { attach: true });
                if (state.trades.some((item) => item.source?.provider === 'toss' && [item.source.externalId, item.source.rawExternalId].includes(normalized.externalId)))
                    continue;
                const trade = tossCandidateToTrade(normalized, { projectId: project.id, id: uid('t') });
                if (!trade)
                    throw new Error('invalid-trade');
                state.trades.push(trade);
                importedTradeIds.add(normalized.externalId);
                affectedProjectIds.add(project.id);
                trade.type === 'sell' ? sells++ : buys++;
            }
            for (const row of plan.dividendCandidates) {
                let project = findProjectForToss(row, { attach: true });
                if (!project) {
                    project = blankProject(row.symbol, row.name);
                    project.colorIndex = state.projects.length % PROJECT_COLORS.length;
                    state.projects.push(project);
                }
                findProjectForToss(row, { attach: true });
                if (state.dividends.some((item) => item.source?.provider === 'toss' && [item.source.externalId, item.source.rawExternalId].includes(row.externalId)))
                    continue;
                const dividend = tossCandidateToDividend(row, { projectId: project.id, id: uid('d'), sharesAtPayment: sharesAtDate(project.id, row.date) });
                if (!dividend)
                    throw new Error('invalid-dividend');
                state.dividends.push(dividend);
                importedDividendIds.add(row.externalId);
                dividends++;
            }
            if ([...affectedProjectIds].some((projectId) => computeProject(projectId).oversells.length))
                throw new Error('oversell');
            if (validateLedger(state).length)
                throw new Error('ledger');
            refreshTossComparisons();
            const supported = (state.integrations.toss.comparisons || []).filter((row) => row.supported);
            if (!supported.length || supported.some((row) => Math.abs(n(row.difference)) >= .0001))
                throw new Error('reconciliation');
            const imported = buys + sells + dividends;
            if (!imported)
                throw new Error('empty-import');
            state.integrations.toss.candidates = plan.candidates.filter((row) => !importedTradeIds.has(String(row?.externalId || '')));
            state.integrations.toss.dividendCandidates = plan.dividendCandidates.filter((row) => !importedDividendIds.has(String(row?.externalId || '')));
            return { imported, buys, sells, dividends, reason: '' };
        }
        catch (error) {
            state = before;
            return { imported: 0, reason: error?.message || 'validation' };
        }
    }
    async function refreshNativeTossStatus() {
        if (!nativeTossStatus.available)
            return nativeTossStatus;
        try {
            nativeTossStatus = { ...nativeTossStatus, ...await nativeTossCredentialStatus() };
        }
        catch (_) {
            nativeTossStatus = { ...nativeTossStatus, configured: false };
        }
        return nativeTossStatus;
    }
    async function refreshAppUpdateStatus() {
        if (!appUpdateStatus.available)
            return appUpdateStatus;
        appUpdateStatus = { ...appUpdateStatus, checking: true, error: '' };
        try {
            appUpdateStatus = { ...appUpdateStatus, ...await fetchHotUpdateStatus(), checking: false, error: '' };
        }
        catch (error) {
            appUpdateStatus = { ...appUpdateStatus, checking: false, error: error?.message || '업데이트 확인 실패' };
        }
        return appUpdateStatus;
    }
    async function applyAppUpdate() {
        if (appUpdateStatus.checking)
            return;
        appUpdateStatus = { ...appUpdateStatus, checking: true, error: '' };
        renderSettings();
        showPage('settings');
        try {
            await installHotUpdate();
            toast('업데이트를 적용하고 다시 시작합니다.');
        }
        catch (error) {
            appUpdateStatus = { ...appUpdateStatus, checking: false, error: error?.message || '업데이트 실패' };
            renderSettings();
            showPage('settings');
            toast(appUpdateStatus.error);
        }
    }
    function openNativeTossSetup() {
        openModal(`<h3 class="modal-title">토스 최초 설정</h3><p class="modal-desc">토스 WTS에서 발급한 Client ID와 Secret을 한 번만 입력하세요. 이 기기의 Android 보안 저장소에 암호화해 보관하며 화면에 다시 표시하지 않습니다.</p><form id="tossNativeSetupForm" class="form-grid"><div><label class="input-label">Client ID</label><input class="input" name="clientId" type="text" autocomplete="off" autocapitalize="none" spellcheck="false" required maxlength="256"></div><div><label class="input-label">Client Secret</label><input class="input" name="clientSecret" type="password" autocomplete="new-password" required maxlength="512"></div><div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">안전하게 저장</button></div></form>`);
        document.getElementById('tossNativeSetupForm').onsubmit = async (event) => {
            event.preventDefault();
            if (modalSaving)
                return;
            modalSaving = true;
            const form = new FormData(event.currentTarget);
            try {
                await saveNativeTossCredentials(form.get('clientId'), form.get('clientSecret'));
                nativeTossStatus = { ...nativeTossStatus, configured: true };
                modalDirty = false;
                closeModal();
                renderSettings();
                showPage('settings');
                toast('토스 키를 이 기기에 저장했습니다.');
                await syncNativeTossReadOnly();
            }
            catch (error) {
                toast(error?.message || '토스 키를 저장하지 못했습니다.');
            }
            finally {
                modalSaving = false;
            }
        };
    }
    async function copyTossIp(ip = pendingTossIp || nativeTossStatus.publicIp) {
        if (!ip) {
            toast('복사할 IP가 없습니다.');
            return;
        }
        try {
            await navigator.clipboard.writeText(ip);
            toast('현재 IP를 복사했습니다.');
        }
        catch (_) {
            toast(`현재 IP: ${ip}`);
        }
    }
    function openTossIpStep(ip) {
        pendingTossIp = ip;
        openModal(`<h3 class="modal-title">토스에 현재 IP 등록</h3><p class="modal-desc">휴대폰 인터넷 주소가 바뀌었습니다. 아래 IP를 복사해 토스 WTS의 설정 → Open API → 허용 IP에 등록하세요.</p><div class="list"><div class="list-row"><div><div class="row-title">현재 IP</div><div class="row-sub">${esc(ip)}</div></div><button class="btn soft small" data-toss-copy-ip>복사</button></div></div><div class="modal-actions"><button class="btn soft" data-open-toss-ip>토스 WTS 열기</button><button class="btn primary" data-confirm-toss-ip>등록 완료 · 갱신</button></div>`);
    }
    async function syncNativeTossReadOnly({ ipConfirmed = false } = {}) {
        if (tossSyncRunning)
            return;
        if (!nativeTossStatus.configured) {
            openNativeTossSetup();
            return;
        }
        nativeTossStatus = { ...nativeTossStatus, checking: true };
        renderSettings();
        showPage('settings');
        let currentIp = '';
        try {
            currentIp = await nativePublicIp();
            nativeTossStatus = { ...nativeTossStatus, publicIp: currentIp, checking: false };
        }
        catch (error) {
            nativeTossStatus = { ...nativeTossStatus, checking: false };
            renderSettings();
            toast(error?.message || '현재 IP를 확인하지 못했습니다.');
            return;
        }
        if (!ipConfirmed && nativeTossStatus.lastPublicIp !== currentIp) {
            renderSettings();
            openTossIpStep(currentIp);
            return;
        }
        pendingTossIp = '';
        return runTossImport(async () => { const snapshot = await fetchNativeTossSnapshot({ from: nextTossSyncFrom(state.integrations.toss), symbols: activeProjects().map((project) => project.symbol) }); await markNativeTossPublicIp(currentIp); nativeTossStatus = { ...nativeTossStatus, lastPublicIp: currentIp }; return snapshot; }, 'Toss Android read-only sync error');
    }
    function tossLinkOf(row) { return { provider: 'toss', assetKey: String(row?.assetKey || ''), market: String(row?.market || ''), securityId: String(row?.securityId || ''), symbol: String(row?.symbol || '').toUpperCase(), currency: String(row?.currency || '').toUpperCase() }; }
    function findProjectForToss(row, { attach = false } = {}) {
        const assetKey = String(row?.assetKey || ''), symbol = String(row?.symbol || '').toUpperCase();
        let project = assetKey ? state.projects.find((item) => !item.archived && (item.brokerLinks || []).some((link) => link.provider === 'toss' && link.assetKey === assetKey)) : null;
        if (!project) {
            const matches = state.projects.filter((item) => !item.archived && item.symbol === symbol);
            if (matches.length === 1)
                project = matches[0];
        }
        if (project && attach && assetKey && !(project.brokerLinks || []).some((link) => link.provider === 'toss' && link.assetKey === assetKey))
            project.brokerLinks = [...(project.brokerLinks || []), tossLinkOf(row)];
        return project || null;
    }
    async function applyTossSnapshot(snapshot, attemptAt) {
        const toss = state.integrations.toss;
        if (accountScopeChanged(toss.accountScopeId, snapshot.accountScopeId))
            throw Object.assign(new Error('연결된 토스 계좌 구성이 바뀌었습니다. 기존 계정 데이터와 섞지 않도록 가져오기를 중단했습니다.'), { code: 'account-scope-changed' });
        const syncProjects = activeProjects(), symbolCounts = new Map();
        for (const project of syncProjects)
            symbolCounts.set(project.symbol, (symbolCounts.get(project.symbol) || 0) + 1);
        const appPositions = syncProjects.flatMap((project) => { const shares = computeProject(project).shares, links = (project.brokerLinks || []).filter((link) => link.provider === 'toss').map((link) => ({ symbol: project.symbol, assetKey: link.assetKey, shares })), symbolFallback = symbolCounts.get(project.symbol) === 1 ? [{ symbol: project.symbol, shares }] : []; return [...links, ...symbolFallback]; });
        const result = buildTossSync(snapshot, { existingTrades: state.trades, existingDividends: state.dividends, appPositions });
        const progress = tossSyncProgress(toss, result);
        Object.assign(toss, { status: result.syncStatus === 'partial' ? 'partial' : 'connected', syncStatus: result.syncStatus, lastSyncAt: result.fetchedAt, ...progress, lastAttemptAt: attemptAt, lastError: '', accountLabel: result.accountLabel, accountScopeId: result.accountScopeId, accountResults: result.accountResults, failedAccountCount: result.failedAccountCount, capabilities: result.capabilities, holdings: result.holdings, comparisons: result.comparisons, ignoredCount: result.ignoredCount, matchedExistingCount: result.matchedExistingCount, matchedExistingDividendCount: result.matchedExistingDividendCount, unsupportedCurrencyCount: result.unsupportedCurrencyCount, historyTruncated: result.historyTruncated, candidates: mergeTossCandidates(toss.candidates, result.candidates), dividendCandidates: mergeTossDividendCandidates(toss.dividendCandidates, result.dividendCandidates), correctionCandidates: mergeTossCorrectionCandidates(toss.correctionCandidates, result.correctionCandidates), dividendCorrectionCandidates: mergeTossDividendCandidates(toss.dividendCorrectionCandidates, result.dividendCorrectionCandidates), syncSequence: n(toss.syncSequence) + 1, sourceLedger: mergeTossSourceLedger(toss.sourceLedger, snapshot, result.fetchedAt) });
        for (const price of result.prices || []) {
            if (price.currency !== 'USD')
                continue;
            const project = findProjectForToss(price);
            if (project) {
                project.currentPrice = price.lastPrice;
                project.priceSource = 'toss';
                project.priceUpdatedAt = price.timestamp || new Date().toISOString();
            }
        }
        const beforeAutomaticChanges = clone(state), adoptedDividends = adoptMatchingTossDividends(), automatic = await tryAutomaticTossImport();
        if (adoptedDividends || automatic.imported)
            await storageSet(SAFETY_KEY, beforeAutomaticChanges);
        await saveState(true);
        renderAll();
        showPage('settings');
        const found = result.candidates.length + result.dividendCandidates.length, changed = result.correctionCandidates.length + result.dividendCorrectionCandidates.length;
        toast(automatic.imported ? `자동 확인 완료 · 매수 ${automatic.buys}건 · 매도 ${automatic.sells}건${automatic.dividends ? ` · 배당 ${automatic.dividends}건` : ''}${adoptedDividends ? ` · 기존 배당 ${adoptedDividends}건 연결` : ''}` : adoptedDividends ? `기존 배당 ${adoptedDividends}건을 중복 없이 토스 원본에 연결했습니다.` : result.syncStatus === 'partial' ? `일부 계좌만 조회됐습니다. 성공한 기록 ${found}건을 보존했습니다.` : changed ? `신규 ${found}건 · 원본 변경 ${changed}건을 확인했습니다.` : found ? `자동 대조를 통과하지 못한 ${found}건만 확인이 필요합니다.` : '토스 계좌와 대조했습니다. 신규 기록은 없습니다.');
    }
    async function runTossImport(loadSnapshot, errorPrefix) {
        if (tossSyncRunning)
            return;
        tossSyncRunning = true;
        const beforeSync = clone(state.integrations.toss), attemptAt = new Date().toISOString();
        state.integrations.toss.status = 'syncing';
        state.integrations.toss.lastAttemptAt = attemptAt;
        state.integrations.toss.lastError = '';
        renderSettings();
        showPage('settings');
        try {
            const snapshot = await loadSnapshot();
            await applyTossSnapshot(snapshot, attemptAt);
        }
        catch (error) {
            console.error(errorPrefix, error);
            state.integrations.toss = { ...beforeSync, status: 'error', lastAttemptAt: attemptAt, lastError: error?.message || '토스 조회 파일을 처리하지 못했습니다.' };
            await saveState();
            renderSettings();
            showPage('settings');
            toast(state.integrations.toss.lastError);
        }
        finally {
            tossSyncRunning = false;
            if (state.integrations.toss.status === 'syncing')
                state.integrations.toss.status = 'not_connected';
            renderSettings();
            showPage('settings');
        }
    }
    async function syncTossReadOnly() {
        if (nativeTossStatus.available)
            return syncNativeTossReadOnly();
        return runTossImport(() => fetchTossSnapshot({ from: nextTossSyncFrom(state.integrations.toss), symbols: activeProjects().map((project) => project.symbol) }), 'Toss read-only sync error');
    }
    async function importTossSnapshotFile(file) {
        return runTossImport(() => readTossSnapshotFile(file), 'Toss snapshot import error');
    }
    function reviewTossCandidates() {
        const candidates = mergeTossCandidates(state.integrations.toss.candidates || [], []), dividendCandidates = mergeTossDividendCandidates(state.integrations.toss.dividendCandidates || [], []);
        state.integrations.toss.candidates = candidates;
        state.integrations.toss.dividendCandidates = dividendCandidates;
        if (!candidates.length && !dividendCandidates.length) {
            toast('검토할 신규 기록이 없습니다.');
            return;
        }
        openModal(`<h3 class="modal-title">토스 신규 기록 검토</h3><p class="modal-desc">선택한 기록만 V4 장부에 저장합니다. 수동 기록과 유사한 후보는 중복 가능성이 있어 기본 선택하지 않습니다.</p><form id="tossReviewForm" class="form-grid"><div class="list">${candidates.map((row, index) => `<label class="list-row"><div><div class="row-title">${esc(row.symbol)} · ${row.type === 'sell' ? '매도' : '매수'} ${fmtShares(row.shares)}주${row.possibleManualDuplicate ? ' · 수동 기록 유사' : ''}</div><div class="row-sub">${fmtDate(row.date)} · 단가 ${fmtMoney(row.price)} · 수수료 ${fmtMoney(row.feeUSD || 0, 2)}${row.accountLabel ? ` · ${esc(row.accountLabel)}` : ''}</div></div><input type="checkbox" name="tradeCandidate" value="${index}" ${row.possibleManualDuplicate ? '' : 'checked'}></label>`).join('')}${dividendCandidates.map((row, index) => `<label class="list-row"><div><div class="row-title">${esc(row.symbol)} · 세후배당 ${fmtMoney(row.amountUSD, 2)}${row.possibleManualDuplicate ? ' · 수동 기록 유사' : ''}</div><div class="row-sub">${fmtDate(row.date)}${row.accountLabel ? ` · ${esc(row.accountLabel)}` : ' · 토스 입금 기록'}</div></div><input type="checkbox" name="dividendCandidate" value="${index}" ${row.possibleManualDuplicate ? '' : 'checked'}></label>`).join('')}</div><div class="modal-actions"><button class="btn soft" type="button" data-close-modal>취소</button><button class="btn primary" type="submit">선택 기록 저장</button></div></form>`);
        document.getElementById('tossReviewForm').onsubmit = async (event) => {
            event.preventDefault();
            const submitted = new FormData(event.currentTarget), selected = new Set(submitted.getAll('tradeCandidate').map(Number)), selectedDividends = new Set(submitted.getAll('dividendCandidate').map(Number));
            if (!selected.size && !selectedDividends.size) {
                toast('저장할 기록을 선택해 주세요.');
                return;
            }
            const projectsBefore = clone(state.projects), tradesBefore = clone(state.trades), dividendsBefore = clone(state.dividends), importedIds = new Set(), importedDividendIds = new Set(), affectedProjectIds = new Set();
            let imported = 0;
            candidates.forEach((row, index) => {
                if (!selected.has(index))
                    return;
                const normalized = normalizeTossOrder(row);
                if (!normalized || normalized.currency !== 'USD')
                    return;
                let project = findProjectForToss(normalized, { attach: true });
                if (!project) {
                    project = blankProject(normalized.symbol, normalized.name);
                    project.colorIndex = state.projects.length % PROJECT_COLORS.length;
                    state.projects.push(project);
                }
                findProjectForToss(normalized, { attach: true });
                const externalId = normalized.externalId;
                if (externalId && state.trades.some((t) => t.source?.provider === 'toss' && t.source.externalId === externalId))
                    return;
                const trade = tossCandidateToTrade(normalized, { projectId: project.id, id: uid('t') });
                if (trade) {
                    state.trades.push(trade);
                    importedIds.add(externalId);
                    affectedProjectIds.add(project.id);
                    imported++;
                }
            });
            dividendCandidates.forEach((row, index) => {
                if (!selectedDividends.has(index))
                    return;
                let project = findProjectForToss(row, { attach: true });
                if (!project) {
                    project = blankProject(row.symbol, row.name);
                    project.colorIndex = state.projects.length % PROJECT_COLORS.length;
                    state.projects.push(project);
                }
                findProjectForToss(row, { attach: true });
                if (state.dividends.some((item) => item.source?.provider === 'toss' && item.source.externalId === row.externalId))
                    return;
                const dividend = tossCandidateToDividend(row, { projectId: project.id, id: uid('d'), sharesAtPayment: sharesAtDate(project.id, row.date) });
                if (dividend) {
                    state.dividends.push(dividend);
                    importedDividendIds.add(row.externalId);
                    imported++;
                }
            });
            const invalid = [...affectedProjectIds].some(projectId => computeProject(projectId).oversells.length);
            if (invalid) {
                state.projects = projectsBefore;
                state.trades = tradesBefore;
                state.dividends = dividendsBefore;
                toast('선택한 거래 조합은 과매도를 만들 수 있어 저장하지 않았습니다. 매수 기록도 함께 선택해 주세요.');
                return;
            }
            if (!imported) {
                state.projects = projectsBefore;
                state.trades = tradesBefore;
                state.dividends = dividendsBefore;
                toast('저장 가능한 신규 기록이 없습니다.');
                return;
            }
            state.integrations.toss.candidates = candidates.filter((row) => !importedIds.has(String(row?.externalId || '')));
            state.integrations.toss.dividendCandidates = dividendCandidates.filter((row) => !importedDividendIds.has(String(row?.externalId || '')));
            state.integrations.toss.lastSyncAt = new Date().toISOString();
            refreshTossComparisons();
            await saveState(true);
            closeModal();
            renderAll();
            showPage('settings');
            toast(`${imported}건을 승인 저장했습니다.`);
        };
    }
    function handleClick(event) {
        const button = event.target.closest('button,[data-open-project],[data-goal-detail]');
        if (!button)
            return;
        if (button.dataset.page) {
            showPage(button.dataset.page);
            return;
        }
        if (button.dataset.currency) {
            if (state.settings.displayCurrency === button.dataset.currency)
                return;
            state.settings.displayCurrency = button.dataset.currency;
            saveState();
            renderAll(true);
            return;
        }
        if (button.dataset.chartKey) {
            chartSelection = button.dataset.chartKey;
            renderProjects();
            return;
        }
        if (button.dataset.incomeMonth) {
            openIncomeMonth(button.dataset.incomeMonth, button.dataset.incomeProject || '', button.dataset.incomeSymbol || '');
            return;
        }
        if ('historyReset' in button.dataset) {
            historyFilter = {};
            historyLimit = 10;
            renderProjects();
            document.querySelector('.record-center').open = true;
            return;
        }
        if ('historyMore' in button.dataset) {
            historyLimit += 10;
            renderProjects();
            document.querySelector('.record-center').open = true;
            return;
        }
        if (button.dataset.chartYearShift) {
            const latest = computeProject(selectedProjectId).postedDividends.map((row) => String(row.date).slice(0, 4)).filter((year) => /^\d{4}$/.test(year)).sort().at(-1) || todayISO().slice(0, 4), base = /^\d{4}$/.test(chartYear) ? Number(chartYear) : Number(latest);
            chartYear = String(base + Number(button.dataset.chartYearShift));
            chartSelection = '';
            renderProjects();
            return;
        }
        if (button.dataset.chartMode) {
            chartMode = button.dataset.chartMode;
            chartSelection = '';
            renderProjects();
            return;
        }
        if (button.dataset.homeCashflowMode) {
            homeCashflowMode = button.dataset.homeCashflowMode;
            cashflowMonthKey = '';
            rememberView();
            renderHome();
            return;
        }
        if (button.dataset.homeYearRange) {
            homeYearRange = button.dataset.homeYearRange;
            cashflowMonthKey = '';
            rememberView();
            renderHome();
            return;
        }
        if (button.dataset.cashflowPeriod) {
            cashflowMonthKey = button.dataset.cashflowPeriod;
            renderHome();
            return;
        }
        if (button.dataset.portfolioGroup) {
            historyFilter = {};
            historyLimit = 10;
            portfolioGroup = button.dataset.portfolioGroup === 'dividend' ? 'dividend' : 'highYield';
            const first = activeProjects().find((project) => (project.category === 'highYield' ? 'highYield' : 'dividend') === portfolioGroup);
            if (first)
                selectedProjectId = first.id;
            renderProjects();
            return;
        }
        if (button.dataset.goalDetail) {
            selectedProjectId = button.dataset.goalDetail;
            renderGoals();
            showPage('goal');
            const card = [...document.querySelectorAll('.goal-step-card')].find(el => el.dataset.goalProject === selectedProjectId);
            if (card) {
                card.open = true;
                card.scrollIntoView({ block: 'nearest' });
            }
            return;
        }
        if (button.dataset.settingsProject) {
            selectedProjectId = button.dataset.settingsProject;
            openProjectForm(projectById(selectedProjectId));
            return;
        }
        if (button.dataset.openProject) {
            selectedProjectId = button.dataset.openProject;
            renderProjects();
            showPage('projects');
            return;
        }
        if (button.dataset.selectProject) {
            historyFilter = {};
            historyLimit = 10;
            selectedProjectId = button.dataset.selectProject;
            renderProjects();
            return;
        }
        if ('addProject' in button.dataset) {
            openProjectForm();
            return;
        }
        if ('projectSettings' in button.dataset) {
            openProjectForm(projectById());
            return;
        }
        if ('editPrice' in button.dataset) {
            openPriceForm();
            return;
        }
        if ('addTrade' in button.dataset) {
            openTradeForm();
            return;
        }
        if ('addDividend' in button.dataset) {
            openDividendForm();
            return;
        }
        if (button.dataset.addDividendFor) {
            selectedProjectId = button.dataset.addDividendFor;
            openDividendForm();
            return;
        }
        if ('addCash' in button.dataset) {
            openCashForm();
            return;
        }
        if (button.dataset.addWithdrawal) {
            selectedProjectId = button.dataset.addWithdrawal;
            openWithdrawalForm(selectedProjectId);
            return;
        }
        if ('addSplit' in button.dataset) {
            openSplitForm();
            return;
        }
        if (button.dataset.viewRecord) {
            openRecordDetail(button.dataset.viewRecord);
            return;
        }
        if (button.dataset.editRecord) {
            editRecord(button.dataset.editRecord);
            return;
        }
        if (button.dataset.deleteFromEdit) {
            deleteRecord(button.dataset.deleteFromEdit);
            return;
        }
        if (button.dataset.deleteRecord) {
            deleteRecord(button.dataset.deleteRecord);
            return;
        }
        if ('projectCheck' in button.dataset) {
            showIssues(selectedProjectId);
            return;
        }
        if ('allCheck' in button.dataset) {
            showIssues();
            return;
        }
        if (button.dataset.goalMode) {
            const [id, mode] = button.dataset.goalMode.split(':');
            const project = projectById(id);
            if (!project || project.afterGoalMode === mode)
                return;
            project.afterGoalMode = mode;
            saveState(true).then(() => { renderAll(); showPage('goal'); const cards = [...document.querySelectorAll('.goal-step-card')]; cards.find((card) => card.querySelector('[data-goal-mode]')?.dataset.goalMode.startsWith(id + ':'))?.setAttribute('open', ''); toast('목표 달성 후 운용 방식을 저장했습니다.'); });
            return;
        }
        if (button.dataset.lockRecovery) {
            lockRecovery(button.dataset.lockRecovery);
            return;
        }
        if (button.dataset.editRecovery) {
            lockRecovery(button.dataset.editRecovery, true);
            return;
        }
        if (button.dataset.restoreProject) {
            const project = projectById(button.dataset.restoreProject);
            if (project) {
                project.archived = false;
                selectedProjectId = project.id;
                saveState(true).then(() => { renderAll(); showPage('projects'); toast('프로젝트를 복원했습니다.'); });
            }
            return;
        }
        if ('localMode' in button.dataset) {
            localOnlySession = true;
            sessionStorage.setItem('dividend-os-local-mode', '1');
            document.getElementById('authGate')?.classList.add('hidden');
            setSaveStatus('');
            return;
        }
        if ('showLogin' in button.dataset) {
            if (demoMode) {
                toast('테스트 모드에서는 클라우드를 연결하지 않습니다.');
                return;
            }
            localOnlySession = false;
            sessionStorage.removeItem('dividend-os-local-mode');
            const gate = document.getElementById('authGate');
            gate?.classList.remove('hidden');
            initAuth().catch(() => { document.getElementById('authGateStatus').textContent = '로그인 서비스를 불러오지 못했습니다. 연결을 확인하고 새로고침해 주세요. 기기 저장은 계속 사용할 수 있습니다.'; });
            requestAnimationFrame(() => gate?.scrollIntoView({ behavior: 'smooth', block: 'start' }));
            return;
        }
        if ('backup' in button.dataset) {
            downloadBackup();
            return;
        }
        if ('backupSave' in button.dataset) {
            saveBackupToChosenLocation();
            return;
        }
        if ('restore' in button.dataset) {
            document.getElementById('restoreInput').click();
            return;
        }
        if ('reviewCloud' in button.dataset) {
            if (currentUser)
                connectCloudForUser(currentUser);
            else
                toast('클라우드 연결 후 사용할 수 있습니다.');
            return;
        }
        if ('restoreSafety' in button.dataset) {
            restoreSafetyCopy().catch(() => toast('안전 사본을 읽지 못했습니다.'));
            return;
        }
        if ('restoreAuto' in button.dataset) {
            restoreLatestAutoBackup().catch(() => toast('자동 백업을 읽지 못했습니다.'));
            return;
        }
        if ('csv' in button.dataset) {
            exportCSV();
            return;
        }
        if ('importToss' in button.dataset) {
            document.getElementById('tossImportInput').click();
            return;
        }
        if ('configureToss' in button.dataset) {
            openNativeTossSetup();
            return;
        }
        if ('tossCopyIp' in button.dataset) {
            copyTossIp();
            return;
        }
        if ('openTossIp' in button.dataset) {
            copyTossIp().finally(() => openTossIpManagement());
            return;
        }
        if ('confirmTossIp' in button.dataset) {
            const ip = pendingTossIp;
            modalDirty = false;
            closeModal();
            syncNativeTossReadOnly({ ipConfirmed: !!ip });
            return;
        }
        if ('clearTossCredentials' in button.dataset) {
            confirmAction('저장한 토스 키 삭제', '이 기기에 암호화 저장한 Client ID와 Secret만 삭제합니다. 가져온 장부 기록은 유지됩니다.', async () => { await clearNativeTossCredentials(); nativeTossStatus = { ...nativeTossStatus, configured: false, publicIp: '', lastPublicIp: '' }; renderSettings(); showPage('settings'); toast('이 기기의 토스 키를 삭제했습니다.'); }, '키 삭제');
            return;
        }
        if ('syncToss' in button.dataset) {
            syncTossReadOnly();
            return;
        }
        if ('installHotUpdate' in button.dataset) {
            applyAppUpdate();
            return;
        }
        if ('checkHotUpdate' in button.dataset) {
            refreshAppUpdateStatus().then(() => { renderSettings(); showPage('settings'); toast(appUpdateStatus.updateAvailable ? '새 업데이트가 있습니다.' : '현재 최신 버전입니다.'); });
            return;
        }
        if ('reviewToss' in button.dataset) {
            reviewTossCandidates();
            return;
        }
        if ('clearTossCorrections' in button.dataset) {
            confirmAction('원본 변경 알림 확인', '토스 원본 변경 알림만 정리합니다. 기존 원장과 원본 보존 기록은 바꾸지 않습니다.', async () => { state.integrations.toss.correctionCandidates = []; state.integrations.toss.dividendCorrectionCandidates = []; await saveState(true); renderSettings(); showPage('settings'); toast('원본 변경 알림을 확인 처리했습니다.'); }, '확인 처리');
            return;
        }
        if ('disconnectToss' in button.dataset) {
            confirmAction('토스 화면 연결 해제', '가져온 거래·배당과 원본 보존 기록은 유지하고 현재 조회 상태와 미승인 후보만 정리합니다.', async () => { state.integrations.toss = disconnectedTossState(state.integrations.toss); await saveState(true); renderAll(); showPage('settings'); toast('토스 조회 화면 연결을 해제했습니다.'); }, '연결 해제');
            return;
        }
        if ('migrateV3' in button.dataset) {
            previewLegacyMigration();
            return;
        }
        if ('logout' in button.dataset) {
            localOnlySession = false;
            sessionStorage.removeItem('dividend-os-local-mode');
            logoutGoogle();
            return;
        }
        if ('reset' in button.dataset) {
            confirmAction('V4 전체 초기화', 'V4 거래·배당·프로젝트를 초기화합니다. V3.2.1 원본은 유지됩니다.', async () => { await storageSet(SAFETY_KEY, clone(state)); await storageDelete(STATE_KEY); state = blankState(); selectedProjectId = state.projects[0].id; await saveState(true); renderAll(); showPage('home'); toast('V4 데이터를 초기화했습니다.'); }, '초기화');
            return;
        }
        if ('discardModal' in button.dataset) {
            closeModal();
            return;
        }
        if ('keepModal' in button.dataset) {
            document.querySelector('.modal-unsaved')?.remove();
            return;
        }
        if ('closeModal' in button.dataset) {
            requestCloseModal();
            return;
        }
    }
    function bindStaticEvents() {
        document.addEventListener('submit', (event) => {
            const form = event.target;
            if (!(form instanceof HTMLFormElement))
                return;
            const futureDate = [...form.querySelectorAll('input[type="date"]')].find((input) => input.value && input.value > todayISO());
            if (futureDate) {
                event.preventDefault();
                event.stopImmediatePropagation();
                futureDate.setCustomValidity('미래 날짜는 실제 기록으로 저장할 수 없습니다.');
                futureDate.reportValidity();
                setTimeout(() => futureDate.setCustomValidity(''), 1200);
                return;
            }
            if (form.dataset.submitting === 'true') {
                event.preventDefault();
                event.stopImmediatePropagation();
                return;
            }
            form.dataset.submitting = 'true';
            setTimeout(() => { if (!form.isConnected)
                return; delete form.dataset.submitting; }, 800);
        }, true);
        document.addEventListener('click', (event) => { handleClick(event); rememberView(); });
        window.addEventListener('pagehide', rememberView);
        document.addEventListener('submit', (event) => { if (event.target.id !== 'historyFilterForm')
            return; event.preventDefault(); const form = new FormData(event.target); historyFilter = { month: String(form.get('month') || ''), kind: String(form.get('kind') || ''), query: String(form.get('query') || '') }; historyLimit = 10; renderProjects(); document.querySelector('.record-center').open = true; });
        document.addEventListener('change', (event) => { if (event.target.matches('[data-project-select]')) {
            selectedProjectId = event.target.value;
            renderProjects();
            rememberView();
            return;
        } if (event.target.matches('[data-chart-year]')) {
            chartYear = event.target.value;
            renderProjects();
            rememberView();
            return;
        } if (!event.target.matches('[data-chart-month]'))
            return; chartMonth = event.target.value; renderProjects(); rememberView(); });
        document.getElementById('modal').addEventListener('input', () => { modalDirty = true; });
        document.getElementById('modal').addEventListener('change', () => { modalDirty = true; });
        document.getElementById('modalBackdrop').addEventListener('click', (event) => { if (event.target.id === 'modalBackdrop')
            requestCloseModal(); });
        document.addEventListener('keydown', (event) => { const card = event.target.closest?.('[data-open-project],[data-goal-detail]'); if (card && (event.key === 'Enter' || event.key === ' ')) {
            event.preventDefault();
            card.click();
            return;
        } if (event.key === 'Escape')
            requestCloseModal(); });
        document.getElementById('restoreInput').addEventListener('change', (event) => { const file = event.target.files?.[0]; if (file)
            restoreFromFile(file); event.target.value = ''; });
        document.getElementById('tossImportInput').addEventListener('change', (event) => { const file = event.target.files?.[0]; if (file)
            importTossSnapshotFile(file); event.target.value = ''; });
        document.addEventListener('submit', (event) => { const id = event.target.id; if (id !== 'displaySettingsForm' && id !== 'dividendSettingsForm')
            return; event.preventDefault(); const form = new FormData(event.target); let next = {}, message = ''; if (id === 'displaySettingsForm') {
            next = { exchangeRate: Math.max(0, n(form.get('exchangeRate'))), exchangeRateMode: form.get('exchangeRateMode') === 'auto' ? 'auto' : 'manual', appearance: String(form.get('appearance')) };
            message = '화면 설정을 저장했습니다.';
        }
        else {
            const thresholdKRW = Math.max(1, n(form.get('thresholdKRW'))), warningKRW = Math.min(thresholdKRW, Math.max(0, n(form.get('warningKRW'))));
            next = { targetMonthlyDividend: Math.max(0, n(form.get('targetMonthlyDividend'))), warningKRW, thresholdKRW };
            message = '배당 기준을 저장했습니다.';
        } if (Object.keys(next).every(key => state.settings[key] === next[key])) {
            toast('바뀐 설정이 없습니다.');
            return;
        } Object.assign(state.settings, next); if (id === 'displaySettingsForm')
            applyTheme(state.settings.appearance); saveState(true).then(() => { renderAll(); showPage('settings'); toast(message); }); });
        matchMedia('(prefers-color-scheme:dark)').addEventListener?.('change', () => { if (state.settings.appearance === 'system')
            applyTheme('system'); });
        window.addEventListener('online', () => { if (currentUser)
            pushCloudState(); });
        window.addEventListener('offline', () => setSaveStatus('오프라인', 'cloud-error'));
    }
    async function init() {
        try {
            removeLegacyTossBrowserCredentials();
            await openStorage();
            const existing = await storageGet(STATE_KEY);
            legacyMigrationSource = demoMode ? null : await readLegacyState();
            if (demoMode)
                state = demoState();
            else if (existing) {
                state = migrate(existing);
                if (legacyMigrationSource && !state.meta.migrationAudit) {
                    const audit = auditLegacyAgainstState(legacyMigrationSource, state);
                    if (audit?.passed)
                        state.meta.migrationAudit = audit;
                    else
                        state.meta.legacyMigrationAvailable = true;
                }
            }
            else if (legacyMigrationSource)
                state = prepareLegacyMigration(legacyMigrationSource).candidate;
            else
                state = blankState();
            selectedProjectId = activeProjects()[0]?.id || '';
            applyTheme(state.settings.appearance);
            await storageSet(STATE_KEY, state);
            await confirmHotUpdateReady().catch(() => { });
            await Promise.all([refreshAutoBackupStatus().catch(() => { }), refreshNativeTossStatus().catch(() => { })]);
            restoreView();
            renderAll();
            bindStaticEvents();
            showPage(currentPage);
            hideSplash();
            setSaveStatus('');
            refreshAppUpdateStatus().then(() => renderSettings()).catch(() => { });
            if (!storageStatus().durable)
                setSaveStatus('임시 저장 · 백업 필요', 'cloud-error');
            if (demoMode) {
                const banner = document.createElement('aside');
                banner.className = 'demo-banner';
                banner.textContent = '테스트 데이터 · 실계좌/클라우드와 분리';
                document.body.prepend(banner);
            }
            if (navigator.onLine && !demoMode)
                initAuth().catch(() => setSaveStatus('기기 저장 모드', 'cloud-error'));
            if (!demoMode && 'serviceWorker' in navigator && location.protocol.startsWith('http'))
                navigator.serviceWorker.register('./sw.js').catch(console.warn);
        }
        catch (error) {
            console.error(error);
            document.getElementById('page-home').innerHTML = '<article class="card danger"><div class="card-title">저장소를 열 수 없습니다.</div><p class="tiny">일반 브라우저 모드에서 다시 열어 주세요.</p></article>';
            setSaveStatus('오류', 'cloud-error');
            hideSplash();
        }
    }
    init();
})();
